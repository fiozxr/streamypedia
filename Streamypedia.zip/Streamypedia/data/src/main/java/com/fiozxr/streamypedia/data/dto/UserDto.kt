package com.fiozxr.streamypedia.data.dto

import com.fiozxr.streamypedia.data.entity.UserEntity

/**
 * API response DTO for a user profile.
 *
 * Excludes the PIN hash for security. Exposes a [hasPin] boolean
 * so clients know whether a PIN prompt is required.
 */
data class UserDto(
    val id: Long,
    val name: String,
    val avatarIndex: Int = 0,
    val isAdmin: Boolean = false,
    val hasPin: Boolean = false,
    val createdAt: Long = 0
) {
    companion object {
        /**
         * Maps a [UserEntity] to a [UserDto], excluding sensitive data.
         *
         * @param entity The source entity from the database.
         * @return A safe-to-transmit [UserDto].
         */
        fun fromEntity(entity: UserEntity): UserDto = UserDto(
            id = entity.id,
            name = entity.name,
            avatarIndex = entity.avatarIndex,
            isAdmin = entity.isAdmin,
            hasPin = entity.pin != null,
            createdAt = entity.createdAt
        )
    }
}
