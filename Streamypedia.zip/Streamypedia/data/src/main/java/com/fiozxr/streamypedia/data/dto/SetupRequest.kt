package com.fiozxr.streamypedia.data.dto

/**
 * Payload for the initial setup wizard.
 *
 * Sent by the client when the server is first configured.
 * Contains all necessary information to bootstrap the
 * Streamypedia instance.
 */
data class SetupRequest(
    /** Display name for the server instance. */
    val serverName: String = "Streamypedia",
    /** TCP port the embedded server should listen on. */
    val port: Int = 8096,
    /** Optional TMDb API key for metadata lookups. */
    val tmdbApiKey: String? = null,
    /** List of library paths to configure during setup. */
    val libraryPaths: List<LibraryPathConfig> = emptyList(),
    /** Name for the initial admin user profile. */
    val adminName: String = "Admin",
    /** Optional PIN for the admin user profile. */
    val adminPin: String? = null
)

/**
 * Represents a single library path configuration
 * used during the setup wizard.
 */
data class LibraryPathConfig(
    /** Absolute path to the media directory. */
    val path: String,
    /** User-friendly display name for this library. */
    val name: String,
    /** Content type: "movie" or "tv". */
    val mediaType: String = "movie"
)
