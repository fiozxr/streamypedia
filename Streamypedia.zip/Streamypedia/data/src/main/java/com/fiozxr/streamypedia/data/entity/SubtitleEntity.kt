package com.fiozxr.streamypedia.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a subtitle track associated with a media item.
 *
 * Subtitles may be external files (srt, vtt, ass) or embedded tracks
 * extracted from the media container.
 */
@Entity(
    tableName = "subtitles",
    foreignKeys = [
        ForeignKey(
            entity = MediaEntity::class,
            parentColumns = ["id"],
            childColumns = ["mediaId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["mediaId"])]
)
data class SubtitleEntity(
    /** Auto-generated primary key. */
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Foreign key to the parent media item. */
    val mediaId: Long,
    /** ISO 639-1 language code (e.g. "en", "es"). */
    val language: String = "en",
    /** Human-readable label (e.g. "English", "Spanish"). */
    val label: String = "English",
    /** Path to the subtitle file on disk. */
    val filePath: String,
    /** Subtitle format: "vtt", "srt", or "ass". */
    val format: String = "vtt",
    /** Whether this subtitle was extracted from the media container. */
    val isEmbedded: Boolean = false,
    /** Track index within the container (for embedded subtitles). */
    val trackIndex: Int = 0
)
