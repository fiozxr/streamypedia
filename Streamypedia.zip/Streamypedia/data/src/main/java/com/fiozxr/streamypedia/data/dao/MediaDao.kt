package com.fiozxr.streamypedia.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.fiozxr.streamypedia.data.entity.MediaEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [MediaEntity].
 *
 * Provides full CRUD operations and specialised queries for
 * library browsing, search, and streaming-readiness checks.
 */
@Dao
interface MediaDao {

    /** Observes all media items ordered alphabetically by title. */
    @Query("SELECT * FROM media ORDER BY title ASC")
    fun getAll(): Flow<List<MediaEntity>>

    /** Observes a single media item by its primary key. */
    @Query("SELECT * FROM media WHERE id = :id")
    fun getById(id: Long): Flow<MediaEntity?>

    /** Retrieves a media item by its TMDb identifier (one-shot). */
    @Query("SELECT * FROM media WHERE tmdbId = :tmdbId")
    suspend fun getByTmdbId(tmdbId: Int): MediaEntity?

    /**
     * Searches media by title using a case-insensitive LIKE query.
     * Matches against both [MediaEntity.title] and [MediaEntity.originalTitle].
     */
    @Query("SELECT * FROM media WHERE title LIKE '%' || :query || '%' OR originalTitle LIKE '%' || :query || '%'")
    fun searchByTitle(query: String): Flow<List<MediaEntity>>

    /** Observes media items whose genres JSON string contains [genre]. */
    @Query("SELECT * FROM media WHERE genres LIKE '%' || :genre || '%'")
    fun getByGenre(genre: String): Flow<List<MediaEntity>>

    /** Observes the most recently added media items, limited to [limit]. */
    @Query("SELECT * FROM media ORDER BY dateAdded DESC LIMIT :limit")
    fun getRecentlyAdded(limit: Int = 20): Flow<List<MediaEntity>>

    /** Observes media items that require transcoding before streaming. */
    @Query("SELECT * FROM media WHERE streamStatus = 'needs_conversion'")
    fun getNeedsConversion(): Flow<List<MediaEntity>>

    /** Observes media items belonging to a specific library folder. */
    @Query("SELECT * FROM media WHERE libraryFolderId = :folderId ORDER BY title ASC")
    fun getByLibraryFolder(folderId: Long): Flow<List<MediaEntity>>

    /** Retrieves a media item by its file path (one-shot). */
    @Query("SELECT * FROM media WHERE filePath = :path LIMIT 1")
    suspend fun getByFilePath(path: String): MediaEntity?

    /** Observes the total number of media records. */
    @Query("SELECT COUNT(*) FROM media")
    fun getMediaCount(): Flow<Int>

    /** Observes the sum of all media file sizes in bytes. */
    @Query("SELECT COALESCE(SUM(fileSize), 0) FROM media")
    fun getTotalFileSize(): Flow<Long>

    /** Inserts or replaces a media entity, returning the row ID. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(media: MediaEntity): Long

    /** Updates an existing media entity. */
    @Update
    suspend fun update(media: MediaEntity)

    /** Deletes a media entity. */
    @Delete
    suspend fun delete(media: MediaEntity)
}
