package com.fiozxr.streamypedia.data.dto

/**
 * DTO representing the current server status.
 *
 * Returned by the server status API endpoint and displayed
 * on the admin dashboard.
 */
data class ServerStatusDto(
    /** Display name of the server. */
    val serverName: String = "Streamypedia",
    /** Application version string. */
    val version: String = "1.0.0",
    /** Server uptime in milliseconds. */
    val uptime: Long = 0,
    /** Number of currently connected users/sessions. */
    val connectedUsers: Int = 0,
    /** Total number of indexed media items. */
    val mediaCount: Int = 0,
    /** Total storage used by media files in bytes. */
    val storageUsed: Long = 0,
    /** Human-readable formatted storage string (e.g. "42.5 GB"). */
    val storageFormatted: String = "0 B"
)
