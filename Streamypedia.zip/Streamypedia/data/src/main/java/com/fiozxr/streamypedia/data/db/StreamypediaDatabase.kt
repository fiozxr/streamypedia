package com.fiozxr.streamypedia.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.fiozxr.streamypedia.data.dao.FavoriteDao
import com.fiozxr.streamypedia.data.dao.LibraryFolderDao
import com.fiozxr.streamypedia.data.dao.MediaDao
import com.fiozxr.streamypedia.data.dao.SubtitleDao
import com.fiozxr.streamypedia.data.dao.UserDao
import com.fiozxr.streamypedia.data.dao.WatchProgressDao
import com.fiozxr.streamypedia.data.entity.FavoriteEntity
import com.fiozxr.streamypedia.data.entity.LibraryFolderEntity
import com.fiozxr.streamypedia.data.entity.MediaEntity
import com.fiozxr.streamypedia.data.entity.SubtitleEntity
import com.fiozxr.streamypedia.data.entity.UserEntity
import com.fiozxr.streamypedia.data.entity.WatchProgressEntity

/**
 * Main Room database for Streamypedia.
 *
 * Aggregates all entity tables and exposes typed DAO accessors
 * for each data domain. The database is created as a singleton
 * via Hilt dependency injection.
 *
 * @see MediaDao
 * @see UserDao
 * @see WatchProgressDao
 * @see SubtitleDao
 * @see LibraryFolderDao
 * @see FavoriteDao
 */
@Database(
    entities = [
        MediaEntity::class,
        UserEntity::class,
        WatchProgressEntity::class,
        SubtitleEntity::class,
        LibraryFolderEntity::class,
        FavoriteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class StreamypediaDatabase : RoomDatabase() {

    /** Returns the DAO for media item operations. */
    abstract fun mediaDao(): MediaDao

    /** Returns the DAO for user profile operations. */
    abstract fun userDao(): UserDao

    /** Returns the DAO for watch progress tracking. */
    abstract fun watchProgressDao(): WatchProgressDao

    /** Returns the DAO for subtitle management. */
    abstract fun subtitleDao(): SubtitleDao

    /** Returns the DAO for library folder management. */
    abstract fun libraryFolderDao(): LibraryFolderDao

    /** Returns the DAO for user favourites. */
    abstract fun favoriteDao(): FavoriteDao
}
