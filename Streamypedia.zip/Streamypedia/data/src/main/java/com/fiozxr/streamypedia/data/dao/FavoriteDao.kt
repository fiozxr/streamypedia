package com.fiozxr.streamypedia.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.fiozxr.streamypedia.data.entity.FavoriteEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [FavoriteEntity].
 *
 * Manages user favourites with reactive observation support.
 */
@Dao
interface FavoriteDao {

    /** Observes all favourites for a user, most recently added first. */
    @Query("SELECT * FROM favorites WHERE userId = :userId ORDER BY addedAt DESC")
    fun getByUser(userId: Long): Flow<List<FavoriteEntity>>

    /** Observes whether a specific media item is favourited by a user. */
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE userId = :userId AND mediaId = :mediaId)")
    fun isFavorite(userId: Long, mediaId: Long): Flow<Boolean>

    /** Inserts or replaces a favourite record. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(fav: FavoriteEntity)

    /** Removes a specific favourite by user and media ID. */
    @Query("DELETE FROM favorites WHERE userId = :userId AND mediaId = :mediaId")
    suspend fun delete(userId: Long, mediaId: Long)
}
