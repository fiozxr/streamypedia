package com.fiozxr.streamypedia.data.dto

import com.fiozxr.streamypedia.data.entity.MediaEntity
import com.google.gson.Gson

/**
 * API response DTO for a media item.
 *
 * Maps from [MediaEntity] and enriches with computed fields
 * such as subtitle count and favourite status. JSON-array fields
 * from the entity are deserialised into typed lists.
 */
data class MediaDto(
    val id: Long,
    val title: String,
    val originalTitle: String? = null,
    val year: Int? = null,
    val overview: String? = null,
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val duration: Long = 0,
    val resolution: String? = null,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val tmdbId: Int? = null,
    val imdbId: String? = null,
    val rating: Float? = null,
    val voteCount: Int? = null,
    val genres: List<String> = emptyList(),
    val cast: List<String> = emptyList(),
    val director: String? = null,
    val mediaType: String = "movie",
    val seriesName: String? = null,
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
    val episodeTitle: String? = null,
    val streamStatus: String = "ready",
    val hlsReady: Boolean = false,
    val hasAdaptiveQuality: Boolean = false,
    val subtitleCount: Int = 0,
    val isFavorite: Boolean = false,
    val dateAdded: Long = 0
) {
    companion object {
        /** Shared Gson instance for JSON parsing. */
        private val gson = Gson()

        /**
         * Maps a [MediaEntity] to a [MediaDto], parsing JSON string fields
         * into typed lists.
         *
         * @param entity The source entity from the database.
         * @param subtitleCount The number of subtitle tracks for this media.
         * @param isFavorite Whether the current user has favourited this media.
         * @return A fully populated [MediaDto].
         */
        fun fromEntity(
            entity: MediaEntity,
            subtitleCount: Int = 0,
            isFavorite: Boolean = false
        ): MediaDto {
            val genresList = entity.genres?.let {
                try {
                    gson.fromJson(it, Array<String>::class.java).toList()
                } catch (e: Exception) {
                    emptyList()
                }
            } ?: emptyList()

            val castList = entity.cast?.let {
                try {
                    gson.fromJson(it, Array<String>::class.java).toList()
                } catch (e: Exception) {
                    emptyList()
                }
            } ?: emptyList()

            return MediaDto(
                id = entity.id,
                title = entity.title,
                originalTitle = entity.originalTitle,
                year = entity.year,
                overview = entity.overview,
                posterPath = entity.posterPath,
                backdropPath = entity.backdropPath,
                duration = entity.duration,
                resolution = entity.resolution,
                videoCodec = entity.videoCodec,
                audioCodec = entity.audioCodec,
                tmdbId = entity.tmdbId,
                imdbId = entity.imdbId,
                rating = entity.rating,
                voteCount = entity.voteCount,
                genres = genresList,
                cast = castList,
                director = entity.director,
                mediaType = entity.mediaType,
                seriesName = entity.seriesName,
                seasonNumber = entity.seasonNumber,
                episodeNumber = entity.episodeNumber,
                episodeTitle = entity.episodeTitle,
                streamStatus = entity.streamStatus,
                hlsReady = entity.hlsReady,
                hasAdaptiveQuality = entity.hasAdaptiveQuality,
                subtitleCount = subtitleCount,
                isFavorite = isFavorite,
                dateAdded = entity.dateAdded
            )
        }
    }
}
