package com.fiozxr.streamypedia.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a media item (movie or TV episode) in the local library.
 *
 * Stores both file-system metadata (path, codec info, resolution) and
 * rich metadata fetched from TMDb (title, overview, poster, cast).
 * JSON-array fields ([genres], [cast]) are persisted as serialised strings
 * and should be converted with Gson at the repository / DTO layer.
 */
@Entity(tableName = "media")
data class MediaEntity(
    /** Auto-generated primary key. */
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Display title of the media item. */
    val title: String,
    /** Original language title, if different from [title]. */
    val originalTitle: String? = null,
    /** Release year. */
    val year: Int? = null,
    /** Plot synopsis from TMDb. */
    val overview: String? = null,
    /** Relative or absolute path to the poster image. */
    val posterPath: String? = null,
    /** Relative or absolute path to the backdrop image. */
    val backdropPath: String? = null,
    /** Absolute path to the media file on disk. */
    val filePath: String,
    /** Name of the media file (e.g. "Movie.mkv"). */
    val fileName: String,
    /** File size in bytes. */
    val fileSize: Long = 0,
    /** Duration in milliseconds. */
    val duration: Long = 0,
    /** Video codec identifier (e.g. "h264", "hevc"). */
    val videoCodec: String? = null,
    /** Audio codec identifier (e.g. "aac", "ac3"). */
    val audioCodec: String? = null,
    /** Container format (e.g. "mkv", "mp4"). */
    val container: String? = null,
    /** Resolution string (e.g. "1920x1080"). */
    val resolution: String? = null,
    /** Overall bitrate in bits per second. */
    val bitrate: Long? = null,
    /** TMDb numeric identifier. */
    val tmdbId: Int? = null,
    /** IMDb identifier string (e.g. "tt1234567"). */
    val imdbId: String? = null,
    /** Average user rating (0-10 scale). */
    val rating: Float? = null,
    /** Number of votes on TMDb. */
    val voteCount: Int? = null,
    /** JSON array of genre names, stored as a string. */
    val genres: String? = null,
    /** JSON array of cast member names, stored as a string. */
    val cast: String? = null,
    /** Director name. */
    val director: String? = null,
    /** Type of media: "movie" or "tv_episode". */
    val mediaType: String = "movie",
    /** Series name if this is a TV episode. */
    val seriesName: String? = null,
    /** Season number if this is a TV episode. */
    val seasonNumber: Int? = null,
    /** Episode number if this is a TV episode. */
    val episodeNumber: Int? = null,
    /** Episode title if this is a TV episode. */
    val episodeTitle: String? = null,
    /** Stream readiness status: "ready", "needs_conversion", "converting", "error". */
    val streamStatus: String = "ready",
    /** Whether HLS segments have been generated. */
    val hlsReady: Boolean = false,
    /** Whether adaptive bitrate variants are available. */
    val hasAdaptiveQuality: Boolean = false,
    /** Timestamp when this record was first created. */
    val dateAdded: Long = System.currentTimeMillis(),
    /** Timestamp when this record was last modified. */
    val dateModified: Long = System.currentTimeMillis(),
    /** Foreign key reference to the library folder that contains this item. */
    val libraryFolderId: Long? = null
)
