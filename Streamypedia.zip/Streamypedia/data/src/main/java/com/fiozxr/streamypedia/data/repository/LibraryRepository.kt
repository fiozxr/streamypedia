package com.fiozxr.streamypedia.data.repository

import com.fiozxr.streamypedia.data.dao.LibraryFolderDao
import com.fiozxr.streamypedia.data.entity.LibraryFolderEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for library folder management.
 *
 * Wraps [LibraryFolderDao] and exposes reactive streams
 * for monitoring configured library paths.
 */
@Singleton
class LibraryRepository @Inject constructor(
    private val libraryFolderDao: LibraryFolderDao
) {

    /** Observes all library folders. */
    fun getAll(): Flow<List<LibraryFolderEntity>> = libraryFolderDao.getAll()

    /** Observes only enabled library folders. */
    fun getEnabled(): Flow<List<LibraryFolderEntity>> = libraryFolderDao.getEnabled()

    /** Inserts or replaces a library folder. Returns the row ID. */
    suspend fun insert(folder: LibraryFolderEntity): Long = libraryFolderDao.insert(folder)

    /** Updates an existing library folder. */
    suspend fun update(folder: LibraryFolderEntity) = libraryFolderDao.update(folder)

    /** Deletes a library folder. */
    suspend fun delete(folder: LibraryFolderEntity) = libraryFolderDao.delete(folder)
}
