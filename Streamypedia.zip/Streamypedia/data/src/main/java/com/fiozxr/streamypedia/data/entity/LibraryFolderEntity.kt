package com.fiozxr.streamypedia.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a monitored library folder on the file system.
 *
 * The media scanner periodically checks enabled folders for new,
 * modified, or removed media files.
 */
@Entity(tableName = "library_folders")
data class LibraryFolderEntity(
    /** Auto-generated primary key. */
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Absolute path to the folder on disk. */
    val path: String,
    /** User-friendly display name for this library. */
    val name: String,
    /** Content type hint: "movie" or "tv". */
    val mediaType: String = "movie",
    /** Timestamp of the last completed scan, or null if never scanned. */
    val lastScanned: Long? = null,
    /** Whether scanning is enabled for this folder. */
    val enabled: Boolean = true
)
