package com.fiozxr.streamypedia.data.dto

/**
 * DTO representing the current library scan status.
 *
 * Emitted during media library scanning to provide real-time
 * progress updates to the UI.
 */
data class ScanStatusDto(
    /** Whether a scan is currently in progress. */
    val isScanning: Boolean = false,
    /** Scan progress as a fraction (0.0 to 1.0). */
    val progress: Float = 0f,
    /** Total number of files discovered for scanning. */
    val totalFiles: Int = 0,
    /** Number of files processed so far. */
    val processedFiles: Int = 0,
    /** Name of the file currently being processed, or null. */
    val currentFile: String? = null
)
