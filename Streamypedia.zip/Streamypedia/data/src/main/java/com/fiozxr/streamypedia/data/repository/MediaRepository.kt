package com.fiozxr.streamypedia.data.repository

import com.fiozxr.streamypedia.data.dao.MediaDao
import com.fiozxr.streamypedia.data.entity.MediaEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for media items.
 *
 * Wraps [MediaDao] and exposes reactive [Flow]-based streams
 * for UI consumption. All write operations are suspend functions
 * that execute on the caller's coroutine context.
 */
@Singleton
class MediaRepository @Inject constructor(
    private val mediaDao: MediaDao
) {

    /** Observes all media items ordered alphabetically. */
    fun getAll(): Flow<List<MediaEntity>> = mediaDao.getAll()

    /** Observes a single media item by its primary key. */
    fun getById(id: Long): Flow<MediaEntity?> = mediaDao.getById(id)

    /** Retrieves a media item by its TMDb ID (one-shot). */
    suspend fun getByTmdbId(tmdbId: Int): MediaEntity? = mediaDao.getByTmdbId(tmdbId)

    /** Searches media by title (reactive). */
    fun searchByTitle(query: String): Flow<List<MediaEntity>> = mediaDao.searchByTitle(query)

    /** Observes media filtered by genre keyword. */
    fun getByGenre(genre: String): Flow<List<MediaEntity>> = mediaDao.getByGenre(genre)

    /** Observes the most recently added items. */
    fun getRecentlyAdded(limit: Int = 20): Flow<List<MediaEntity>> = mediaDao.getRecentlyAdded(limit)

    /** Observes media items that need transcoding. */
    fun getNeedsConversion(): Flow<List<MediaEntity>> = mediaDao.getNeedsConversion()

    /** Observes media belonging to a specific library folder. */
    fun getByLibraryFolder(folderId: Long): Flow<List<MediaEntity>> = mediaDao.getByLibraryFolder(folderId)

    /** Retrieves a media item by file path (one-shot). */
    suspend fun getByFilePath(path: String): MediaEntity? = mediaDao.getByFilePath(path)

    /** Observes the total media count. */
    fun getMediaCount(): Flow<Int> = mediaDao.getMediaCount()

    /** Observes the total file size across all media. */
    fun getTotalFileSize(): Flow<Long> = mediaDao.getTotalFileSize()

    /** Inserts or replaces a media entity. Returns the row ID. */
    suspend fun insert(media: MediaEntity): Long = mediaDao.insert(media)

    /** Updates an existing media entity. */
    suspend fun update(media: MediaEntity) = mediaDao.update(media)

    /** Deletes a media entity. */
    suspend fun delete(media: MediaEntity) = mediaDao.delete(media)
}
