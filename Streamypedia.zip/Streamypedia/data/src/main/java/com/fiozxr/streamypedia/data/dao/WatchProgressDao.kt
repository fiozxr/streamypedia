package com.fiozxr.streamypedia.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.fiozxr.streamypedia.data.entity.WatchProgressEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [WatchProgressEntity].
 *
 * Manages playback progress tracking, "continue watching" lists,
 * and completion status.
 */
@Dao
interface WatchProgressDao {

    /** Observes the progress for a specific user–media pair. */
    @Query("SELECT * FROM watch_progress WHERE userId = :userId AND mediaId = :mediaId")
    fun getByUserAndMedia(userId: Long, mediaId: Long): Flow<WatchProgressEntity?>

    /**
     * Observes incomplete items for a user, sorted by most recently watched.
     * Used to build the "Continue Watching" row on the home screen.
     */
    @Query("SELECT * FROM watch_progress WHERE userId = :userId AND completed = 0 ORDER BY lastWatched DESC LIMIT :limit")
    fun getContinueWatching(userId: Long, limit: Int = 20): Flow<List<WatchProgressEntity>>

    /** Inserts or replaces a progress record (upsert semantics). */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(progress: WatchProgressEntity)

    /** Marks a media item as completed for a user. */
    @Query("UPDATE watch_progress SET completed = 1, lastWatched = :timestamp WHERE userId = :userId AND mediaId = :mediaId")
    suspend fun markCompleted(userId: Long, mediaId: Long, timestamp: Long = System.currentTimeMillis())

    /** Deletes all progress records for a user (used when deleting a user profile). */
    @Query("DELETE FROM watch_progress WHERE userId = :userId")
    suspend fun deleteForUser(userId: Long)
}
