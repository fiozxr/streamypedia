package com.fiozxr.streamypedia.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

/**
 * Junction entity linking a user to a media item they have favourited.
 *
 * Uses a composite primary key of [userId] and [mediaId].
 * Cascade-deletes when the parent user or media record is removed.
 */
@Entity(
    tableName = "favorites",
    primaryKeys = ["userId", "mediaId"],
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MediaEntity::class,
            parentColumns = ["id"],
            childColumns = ["mediaId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["userId"]),
        Index(value = ["mediaId"])
    ]
)
data class FavoriteEntity(
    /** Reference to the user. */
    val userId: Long,
    /** Reference to the favourited media item. */
    val mediaId: Long,
    /** Timestamp when the item was favourited. */
    val addedAt: Long = System.currentTimeMillis()
)
