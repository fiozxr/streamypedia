package com.fiozxr.streamypedia.data.dto

import com.fiozxr.streamypedia.data.entity.WatchProgressEntity

/**
 * API request/response DTO for playback progress.
 *
 * Includes a computed [progressPercent] for easy progress-bar rendering.
 */
data class WatchProgressDto(
    val userId: Long,
    val mediaId: Long,
    val position: Long = 0,
    val duration: Long = 0,
    val completed: Boolean = false,
    val lastWatched: Long = 0,
    val progressPercent: Float = 0f
) {
    companion object {
        /**
         * Maps a [WatchProgressEntity] to a [WatchProgressDto].
         *
         * @param entity The source entity from the database.
         * @return A [WatchProgressDto] with computed progress percentage.
         */
        fun fromEntity(entity: WatchProgressEntity): WatchProgressDto = WatchProgressDto(
            userId = entity.userId,
            mediaId = entity.mediaId,
            position = entity.position,
            duration = entity.duration,
            completed = entity.completed,
            lastWatched = entity.lastWatched,
            progressPercent = if (entity.duration > 0) {
                entity.position.toFloat() / entity.duration * 100f
            } else {
                0f
            }
        )
    }
}
