package com.fiozxr.streamypedia.data.repository

import com.fiozxr.streamypedia.data.dao.UserDao
import com.fiozxr.streamypedia.data.entity.UserEntity
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for user profiles.
 *
 * Wraps [UserDao] and provides PIN hashing/verification utilities.
 */
@Singleton
class UserRepository @Inject constructor(
    private val userDao: UserDao
) {

    /** Observes all user profiles ordered by name. */
    fun getAll(): Flow<List<UserEntity>> = userDao.getAll()

    /** Observes a single user profile by primary key. */
    fun getById(id: Long): Flow<UserEntity?> = userDao.getById(id)

    /** Retrieves the first admin user (one-shot). */
    suspend fun getAdmin(): UserEntity? = userDao.getAdmin()

    /** Observes the total number of registered users. */
    fun getUserCount(): Flow<Int> = userDao.getUserCount()

    /** Inserts a new user profile. Returns the generated row ID. */
    suspend fun insert(user: UserEntity): Long = userDao.insert(user)

    /** Updates an existing user profile. */
    suspend fun update(user: UserEntity) = userDao.update(user)

    /** Deletes a user profile. */
    suspend fun delete(user: UserEntity) = userDao.delete(user)

    /**
     * Hashes a plain-text PIN using SHA-256.
     *
     * @param pin The plain-text PIN to hash.
     * @return The hex-encoded SHA-256 digest string.
     */
    fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Verifies a plain-text PIN against a stored SHA-256 hash.
     *
     * @param pin The plain-text PIN entered by the user.
     * @param storedHash The stored SHA-256 hash to compare against.
     * @return `true` if the PIN matches.
     */
    fun verifyPin(pin: String, storedHash: String): Boolean = hashPin(pin) == storedHash
}
