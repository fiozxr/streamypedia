package com.fiozxr.streamypedia.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

/**
 * Tracks per-user, per-media playback progress.
 *
 * Uses a composite primary key of [userId] and [mediaId].
 * Cascade-deletes when the parent user or media record is removed.
 */
@Entity(
    tableName = "watch_progress",
    primaryKeys = ["userId", "mediaId"],
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MediaEntity::class,
            parentColumns = ["id"],
            childColumns = ["mediaId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["userId"]),
        Index(value = ["mediaId"])
    ]
)
data class WatchProgressEntity(
    /** Reference to the user. */
    val userId: Long,
    /** Reference to the media item. */
    val mediaId: Long,
    /** Current playback position in milliseconds. */
    val position: Long = 0,
    /** Total duration in milliseconds (cached from media). */
    val duration: Long = 0,
    /** Whether the user has finished watching this item. */
    val completed: Boolean = false,
    /** Timestamp of the most recent playback session. */
    val lastWatched: Long = System.currentTimeMillis()
)
