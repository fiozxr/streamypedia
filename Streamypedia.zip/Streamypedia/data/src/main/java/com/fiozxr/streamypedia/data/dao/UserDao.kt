package com.fiozxr.streamypedia.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.fiozxr.streamypedia.data.entity.UserEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [UserEntity].
 *
 * Manages user profile CRUD operations and admin lookups.
 */
@Dao
interface UserDao {

    /** Observes all user profiles ordered by name. */
    @Query("SELECT * FROM users ORDER BY name ASC")
    fun getAll(): Flow<List<UserEntity>>

    /** Observes a single user profile by primary key. */
    @Query("SELECT * FROM users WHERE id = :id")
    fun getById(id: Long): Flow<UserEntity?>

    /** Retrieves the first admin user (one-shot). */
    @Query("SELECT * FROM users WHERE isAdmin = 1 LIMIT 1")
    suspend fun getAdmin(): UserEntity?

    /** Observes the total number of registered users. */
    @Query("SELECT COUNT(*) FROM users")
    fun getUserCount(): Flow<Int>

    /** Inserts a new user profile. Aborts on conflict. */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(user: UserEntity): Long

    /** Updates an existing user profile. */
    @Update
    suspend fun update(user: UserEntity)

    /** Deletes a user profile. */
    @Delete
    suspend fun delete(user: UserEntity)
}
