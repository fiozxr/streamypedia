package com.fiozxr.streamypedia.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a user profile within Streamypedia.
 *
 * Each user has a display name, an avatar chosen from a predefined set,
 * an optional hashed PIN for profile-lock, and an admin flag that
 * controls access to server administration features.
 */
@Entity(tableName = "users")
data class UserEntity(
    /** Auto-generated primary key. */
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Display name shown in the profile selector. */
    val name: String,
    /** Index into the predefined avatar drawable set (0-based). */
    val avatarIndex: Int = 0,
    /** SHA-256 hashed PIN string; null means no PIN is required. */
    val pin: String? = null,
    /** Whether this user has administrator privileges. */
    val isAdmin: Boolean = false,
    /** Timestamp when this profile was created. */
    val createdAt: Long = System.currentTimeMillis()
)
