package com.fiozxr.streamypedia.data.repository

import com.fiozxr.streamypedia.data.dao.FavoriteDao
import com.fiozxr.streamypedia.data.entity.FavoriteEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for user favourites.
 *
 * Wraps [FavoriteDao] and exposes reactive streams for
 * favourite status observation.
 */
@Singleton
class FavoriteRepository @Inject constructor(
    private val favoriteDao: FavoriteDao
) {

    /** Observes all favourites for a user, most recently added first. */
    fun getByUser(userId: Long): Flow<List<FavoriteEntity>> = favoriteDao.getByUser(userId)

    /** Observes whether a specific media item is favourited by a user. */
    fun isFavorite(userId: Long, mediaId: Long): Flow<Boolean> =
        favoriteDao.isFavorite(userId, mediaId)

    /** Adds a media item to a user's favourites. */
    suspend fun insert(fav: FavoriteEntity) = favoriteDao.insert(fav)

    /** Removes a media item from a user's favourites. */
    suspend fun delete(userId: Long, mediaId: Long) = favoriteDao.delete(userId, mediaId)
}
