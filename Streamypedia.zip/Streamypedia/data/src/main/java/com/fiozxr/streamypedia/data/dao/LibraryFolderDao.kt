package com.fiozxr.streamypedia.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.fiozxr.streamypedia.data.entity.LibraryFolderEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [LibraryFolderEntity].
 *
 * Manages library folder CRUD operations and provides filtered
 * queries for enabled/disabled folders.
 */
@Dao
interface LibraryFolderDao {

    /** Observes all library folders ordered by name. */
    @Query("SELECT * FROM library_folders ORDER BY name ASC")
    fun getAll(): Flow<List<LibraryFolderEntity>>

    /** Observes only enabled library folders ordered by name. */
    @Query("SELECT * FROM library_folders WHERE enabled = 1 ORDER BY name ASC")
    fun getEnabled(): Flow<List<LibraryFolderEntity>>

    /** Inserts or replaces a library folder record. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(folder: LibraryFolderEntity): Long

    /** Updates an existing library folder. */
    @Update
    suspend fun update(folder: LibraryFolderEntity)

    /** Deletes a library folder record. */
    @Delete
    suspend fun delete(folder: LibraryFolderEntity)
}
