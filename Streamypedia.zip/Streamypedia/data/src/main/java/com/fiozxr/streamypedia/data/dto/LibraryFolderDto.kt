package com.fiozxr.streamypedia.data.dto

import com.fiozxr.streamypedia.data.entity.LibraryFolderEntity

/**
 * API response DTO for a library folder.
 *
 * Enriches the entity with a [mediaCount] indicating how many
 * media items belong to this folder.
 */
data class LibraryFolderDto(
    val id: Long = 0,
    val path: String,
    val name: String,
    val mediaType: String = "movie",
    val lastScanned: Long? = null,
    val enabled: Boolean = true,
    val mediaCount: Int = 0
) {
    companion object {
        /**
         * Maps a [LibraryFolderEntity] to a [LibraryFolderDto].
         *
         * @param entity The source entity from the database.
         * @param mediaCount Number of media items in this folder.
         * @return A fully populated [LibraryFolderDto].
         */
        fun fromEntity(
            entity: LibraryFolderEntity,
            mediaCount: Int = 0
        ): LibraryFolderDto = LibraryFolderDto(
            id = entity.id,
            path = entity.path,
            name = entity.name,
            mediaType = entity.mediaType,
            lastScanned = entity.lastScanned,
            enabled = entity.enabled,
            mediaCount = mediaCount
        )
    }
}
