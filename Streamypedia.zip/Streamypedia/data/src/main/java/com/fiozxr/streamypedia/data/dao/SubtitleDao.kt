package com.fiozxr.streamypedia.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.fiozxr.streamypedia.data.entity.SubtitleEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [SubtitleEntity].
 *
 * Provides queries for retrieving and managing subtitle tracks
 * associated with media items.
 */
@Dao
interface SubtitleDao {

    /** Observes all subtitle tracks for a given media item, ordered by language. */
    @Query("SELECT * FROM subtitles WHERE mediaId = :mediaId ORDER BY language ASC")
    fun getByMediaId(mediaId: Long): Flow<List<SubtitleEntity>>

    /** Inserts or replaces a subtitle record. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subtitle: SubtitleEntity): Long

    /** Deletes all subtitle records for a given media item. */
    @Query("DELETE FROM subtitles WHERE mediaId = :mediaId")
    suspend fun deleteByMediaId(mediaId: Long)
}
