package com.fiozxr.streamypedia.data.repository

import com.fiozxr.streamypedia.data.dao.WatchProgressDao
import com.fiozxr.streamypedia.data.entity.WatchProgressEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for playback progress tracking.
 *
 * Wraps [WatchProgressDao] and exposes reactive streams for
 * "continue watching" functionality.
 */
@Singleton
class WatchProgressRepository @Inject constructor(
    private val watchProgressDao: WatchProgressDao
) {

    /** Observes the progress for a specific user–media pair. */
    fun getByUserAndMedia(userId: Long, mediaId: Long): Flow<WatchProgressEntity?> =
        watchProgressDao.getByUserAndMedia(userId, mediaId)

    /** Observes incomplete items for a user ("continue watching" row). */
    fun getContinueWatching(userId: Long, limit: Int = 20): Flow<List<WatchProgressEntity>> =
        watchProgressDao.getContinueWatching(userId, limit)

    /** Inserts or replaces a progress record. */
    suspend fun upsert(progress: WatchProgressEntity) = watchProgressDao.upsert(progress)

    /** Marks a media item as completed for a user. */
    suspend fun markCompleted(userId: Long, mediaId: Long) =
        watchProgressDao.markCompleted(userId, mediaId)

    /** Deletes all progress records for a user. */
    suspend fun deleteForUser(userId: Long) = watchProgressDao.deleteForUser(userId)
}
