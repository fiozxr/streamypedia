# Streamypedia

> **"Your phone. Your library. Your stream."**

Turn any Android phone (especially old, retired phones) into a self-hosted personal media streaming server — a lightweight, modern, mobile-first alternative to Jellyfin/Plex, running entirely on-device.

## Features (v1)
*   **On-Device Media Server**: Ktor-based embedded HTTP server running as a foreground service.
*   **Liquid Crystal Glass UI**: A beautiful, translucent glassmorphism design system across Android and Web.
*   **Web Client**: Dedicated web client served directly from the phone. Any browser on the same network can access it at `http://<phone-ip>:8096`.
*   **HLS Streaming**: On-the-fly HLS remuxing via FFmpeg. No heavy video re-encoding by default; only audio is transcoded to AAC if incompatible with browsers.
*   **Metadata fetching**: Integrates with TMDb to pull posters, backdrops, and cast information.
*   **Multiple Profiles**: Separate watch histories and progress for different users.

## Tech Stack
*   **Android**: Kotlin, Jetpack Compose, Hilt, Room, Coil, ExoPlayer (Media3), WorkManager.
*   **Server**: Ktor, FFmpeg Kit for Android.
*   **Web Client**: Plain HTML/CSS/JS, hls.js (No build tools required for the web client).

## Setup
1. Open the app on your Android device.
2. Complete the setup wizard (Select media folders, enter TMDb API key).
3. The server will start scanning your media and making it available.
4. Visit the web client on any browser using the IP address shown in the app.

## Project Structure
- `:app` - DI, Foreground Services, Main Activity
- `:server` - Ktor Server, HLS Pipeline (FFmpeg), Codec Analyzer, API Routes
- `:data` - Room Database, Repositories, DTOs
- `:ui` - Liquid Crystal Glass Theme, Compose Screens
- `webclient/` - HTML/JS/CSS Web Client

## API Overview
Streamypedia exposes a RESTful JSON API used identically by both the native Android app and the Web Client.
- `GET /api/v1/library`
- `GET /api/v1/stream/{id}/master.m3u8`
- `GET /api/v1/media/{id}/subtitles`
- `POST /api/v1/users/{id}/progress`
- *And many more...*

## Post-v1 Roadmap
- Hardware-accelerated background video transcoding for "Needs Conversion" files.
- Music library mode.
- Chromecast/DLNA casting support.
- Trakt.tv sync.

## License
Apache 2.0
