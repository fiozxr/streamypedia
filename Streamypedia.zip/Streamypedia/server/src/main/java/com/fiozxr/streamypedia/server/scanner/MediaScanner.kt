package com.fiozxr.streamypedia.server.scanner

import com.fiozxr.streamypedia.data.entity.LibraryFolderEntity
import com.fiozxr.streamypedia.data.entity.MediaEntity
import com.fiozxr.streamypedia.data.repository.LibraryRepository
import com.fiozxr.streamypedia.data.repository.MediaRepository
import com.fiozxr.streamypedia.server.codec.CodeAnalyzer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaScanner @Inject constructor(
    private val libraryRepository: LibraryRepository,
    private val mediaRepository: MediaRepository,
    private val codeAnalyzer: CodeAnalyzer
) {
    private val _scanProgress = MutableStateFlow(ScanStatus(false, 0, 0, 0))
    val scanProgress: StateFlow<ScanStatus> = _scanProgress.asStateFlow()
    
    private val supportedExtensions = setOf("mp4", "mkv", "mov", "webm", "avi", "m4v")

    suspend fun scan() = withContext(Dispatchers.IO) {
        if (_scanProgress.value.isScanning) return@withContext
        
        _scanProgress.value = ScanStatus(true, 0, 0, 0)
        
        try {
            val folders = libraryRepository.getAllFolders().first()
            val allFiles = mutableListOf<Pair<LibraryFolderEntity, File>>()
            
            // Gather files
            folders.filter { it.enabled }.forEach { folder ->
                val root = File(folder.path)
                if (root.exists() && root.isDirectory) {
                    root.walkTopDown()
                        .filter { it.isFile && supportedExtensions.contains(it.extension.lowercase()) }
                        .forEach { allFiles.add(Pair(folder, it)) }
                }
            }
            
            val total = allFiles.size
            _scanProgress.value = ScanStatus(true, 0f, total, 0)
            
            // Process files
            allFiles.forEachIndexed { index, (folder, file) ->
                processFile(folder, file)
                val progress = ((index + 1).toFloat() / total.toFloat()) * 100f
                _scanProgress.value = ScanStatus(true, progress, total, index + 1)
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            _scanProgress.value = ScanStatus(false, 100f, _scanProgress.value.totalFiles, _scanProgress.value.processedFiles)
        }
    }

    private suspend fun processFile(folder: LibraryFolderEntity, file: File) {
        // Skip if already exists and unmodified
        val existing = mediaRepository.getMediaByPath(file.absolutePath)
        if (existing != null && existing.fileSize == file.length()) {
            return
        }

        // Analyze codec
        val codecInfo = codeAnalyzer.analyze(file.absolutePath)
        
        // Parse name
        val parsedName = file.nameWithoutExtension.replace(".", " ") // simple parsing
        
        val entity = MediaEntity(
            id = existing?.id ?: 0,
            title = parsedName,
            originalTitle = parsedName,
            filePath = file.absolutePath,
            fileName = file.name,
            fileSize = file.length(),
            duration = codecInfo.duration,
            videoCodec = codecInfo.videoCodec,
            audioCodec = codecInfo.audioCodec,
            container = codecInfo.container,
            resolution = codecInfo.resolution,
            bitrate = codecInfo.bitrate,
            mediaType = folder.mediaType,
            streamStatus = if (codecInfo.needsConversion) "needs_conversion" else "ready",
            libraryFolderId = folder.id,
            dateAdded = existing?.dateAdded ?: System.currentTimeMillis(),
            dateModified = System.currentTimeMillis()
        )
        
        if (existing == null) {
            mediaRepository.insertMedia(entity)
        } else {
            mediaRepository.updateMedia(entity)
        }
    }
}

data class ScanStatus(
    val isScanning: Boolean,
    val progress: Float,
    val totalFiles: Int,
    val processedFiles: Int
)
