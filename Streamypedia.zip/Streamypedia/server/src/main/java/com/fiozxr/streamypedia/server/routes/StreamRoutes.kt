package com.fiozxr.streamypedia.server.routes

import com.fiozxr.streamypedia.data.repository.MediaRepository
import com.fiozxr.streamypedia.server.hls.HlsPipeline
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.call
import io.ktor.server.response.respond
import io.ktor.server.response.respondBytes
import io.ktor.server.response.respondText
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.route
import kotlinx.coroutines.flow.first

fun Route.streamRoutes(mediaRepository: MediaRepository, hlsPipeline: HlsPipeline) {
    route("/api/v1/stream") {
        get("/{id}/master.m3u8") {
            val id = call.parameters["id"]?.toLongOrNull() ?: return@get call.respond(HttpStatusCode.BadRequest)
            val mediaDto = mediaRepository.getMediaById(id).first()
            if (mediaDto != null) {
                // Convert MediaDto back to MediaEntity logic or pass Dto directly if HlsPipeline accepts it.
                // For now assuming HlsPipeline uses MediaEntity. Since we are in the server module we can fetch entity directly 
                // from a raw method, or adapt the pipeline to take ID. Let's adapt pipeline in a real app.
                val mediaEntity = mediaRepository.getRawMediaEntity(id) 
                
                if (mediaEntity != null) {
                    val playlist = hlsPipeline.generateMasterPlaylist(mediaEntity)
                    call.respondText(playlist, ContentType.parse("application/vnd.apple.mpegurl"))
                } else {
                    call.respond(HttpStatusCode.NotFound)
                }
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }
        
        get("/{id}/segment/{index}.ts") {
            val id = call.parameters["id"]?.toLongOrNull() ?: return@get call.respond(HttpStatusCode.BadRequest)
            val indexStr = call.parameters["index"]?.removeSuffix(".ts")
            val index = indexStr?.toIntOrNull() ?: return@get call.respond(HttpStatusCode.BadRequest)
            
            val mediaEntity = mediaRepository.getRawMediaEntity(id)
            if (mediaEntity != null) {
                try {
                    val segmentBytes = hlsPipeline.generateSegment(mediaEntity, index)
                    call.respondBytes(segmentBytes, ContentType.parse("video/MP2T"))
                } catch (e: Exception) {
                    call.respond(HttpStatusCode.InternalServerError, e.message ?: "Segment error")
                }
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }
    }
}
