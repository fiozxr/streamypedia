package com.fiozxr.streamypedia.server

data class ServerConfig(
    val port: Int = 8096,
    val serverName: String = "Streamypedia",
    val tmdbApiKey: String? = null,
    val remoteAccessEnabled: Boolean = false,
    val backgroundConversionEnabled: Boolean = false,
    val setupComplete: Boolean = false
)
