package com.fiozxr.streamypedia.server

import android.content.Context
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.serialization.gson.gson
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.netty.NettyApplicationEngine
import io.ktor.server.plugins.callloging.CallLogging
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.cors.routing.CORS
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.response.respondText
import io.ktor.server.routing.routing
import javax.inject.Inject
import javax.inject.Singleton
import com.fiozxr.streamypedia.server.routes.*
import com.fiozxr.streamypedia.data.repository.*
import com.fiozxr.streamypedia.server.hls.HlsPipeline

@Singleton
class KtorServer @Inject constructor(
    private val context: Context,
    private val mediaRepository: MediaRepository,
    private val userRepository: UserRepository,
    private val watchProgressRepository: WatchProgressRepository,
    private val hlsPipeline: HlsPipeline,
    private var config: ServerConfig
) {
    private var server: NettyApplicationEngine? = null

    fun updateConfig(newConfig: ServerConfig) {
        config = newConfig
    }

    fun start() {
        if (server != null) return
        
        server = embeddedServer(Netty, port = config.port) {
            installPlugins()
            
            routing {
                libraryRoutes(mediaRepository)
                streamRoutes(mediaRepository, hlsPipeline)
                userRoutes(userRepository)
                progressRoutes(watchProgressRepository, mediaRepository)
                webClientRoutes(context)
            }
        }.start(wait = false)
    }

    fun stop() {
        server?.stop(1000, 2000)
        server = null
    }

    private fun Application.installPlugins() {
        install(ContentNegotiation) {
            gson {
                setPrettyPrinting()
            }
        }
        install(CORS) {
            anyHost() // Allow LAN access
            allowHeader(HttpHeaders.ContentType)
            allowHeader(HttpHeaders.Authorization)
            allowMethod(HttpMethod.Options)
            allowMethod(HttpMethod.Put)
            allowMethod(HttpMethod.Patch)
            allowMethod(HttpMethod.Delete)
        }
        install(CallLogging)
        install(StatusPages) {
            exception<Throwable> { call, cause ->
                call.respondText(text = "500: $cause", status = io.ktor.http.HttpStatusCode.InternalServerError)
            }
        }
    }
}
