package com.fiozxr.streamypedia.server.hls

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.fiozxr.streamypedia.data.entity.MediaEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HlsPipeline @Inject constructor(
    private val context: Context
) {
    // Segment duration in seconds
    private val segmentDuration = 6
    private val cacheDir = File(context.cacheDir, "hls_cache").apply { mkdirs() }

    // Generate master playlist for a media item
    fun generateMasterPlaylist(media: MediaEntity): String {
        val segmentCount = getSegmentCount(media.duration)
        val sb = StringBuilder()
        sb.append("#EXTM3U\n")
        sb.append("#EXT-X-VERSION:3\n")
        sb.append("#EXT-X-TARGETDURATION:$segmentDuration\n")
        sb.append("#EXT-X-MEDIA-SEQUENCE:0\n")
        
        for (i in 0 until segmentCount) {
            // Last segment might be shorter
            val dur = if (i == segmentCount - 1) {
                val remaining = (media.duration / 1000.0) - (i * segmentDuration)
                if (remaining > 0) remaining else segmentDuration.toDouble()
            } else {
                segmentDuration.toDouble()
            }
            
            sb.append("#EXTINF:$dur,\n")
            sb.append("/api/v1/stream/${media.id}/segment/$i.ts\n")
        }
        
        sb.append("#EXT-X-ENDLIST\n")
        return sb.toString()
    }

    // Generate segment at given index (on-the-fly remux)
    suspend fun generateSegment(media: MediaEntity, segmentIndex: Int): ByteArray = withContext(Dispatchers.IO) {
        val mediaDir = File(cacheDir, media.id.toString()).apply { mkdirs() }
        val segmentFile = File(mediaDir, "seg_$segmentIndex.ts")
        
        if (segmentFile.exists() && segmentFile.length() > 0) {
            return@withContext segmentFile.readBytes()
        }

        val startTime = segmentIndex * segmentDuration
        
        // Decision flow based on codec
        // 1. Check video codec against allowlist (already done, streamStatus would be "needs_conversion" if not allowed)
        // 2. If video allowed + audio is AAC: direct remux to .ts segments (ffmpeg -c copy)
        // 3. If video allowed + audio is NOT AAC (DTS, AC3, etc.): remux video (copy) + transcode audio to AAC
        
        val audioCodec = if (media.audioCodec == "aac") "copy" else "aac"
        
        val cmd = "-ss $startTime -t $segmentDuration -i \"${media.filePath}\" " +
                  "-c:v copy -c:a $audioCodec " +
                  "-map 0:v:0 -map 0:a:0? " + // Map first video and first audio (if exists)
                  "-f mpegts -y \"${segmentFile.absolutePath}\""
                  
        val session = FFmpegKit.execute(cmd)
        if (session.returnCode.isValueSuccess) {
            segmentFile.readBytes()
        } else {
            throw RuntimeException("FFmpeg failed to generate segment: ${session.failStackTrace}")
        }
    }

    // Calculate total segment count from duration
    fun getSegmentCount(durationMs: Long): Int {
        val durationSec = durationMs / 1000.0
        return Math.ceil(durationSec / segmentDuration).toInt()
    }

    // Clean up cached segments for a media item
    fun cleanupCache(mediaId: Long) {
        val mediaDir = File(cacheDir, mediaId.toString())
        if (mediaDir.exists()) {
            mediaDir.deleteRecursively()
        }
    }
}
