package com.fiozxr.streamypedia.server.routes

import com.fiozxr.streamypedia.data.repository.UserRepository
import io.ktor.server.application.call
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.route
import kotlinx.coroutines.flow.first

fun Route.userRoutes(userRepository: UserRepository) {
    route("/api/v1/users") {
        get {
            val users = userRepository.getAllUsers().first()
            call.respond(users)
        }
        
        get("/{id}") {
            val id = call.parameters["id"]?.toLongOrNull()
            if (id != null) {
                val user = userRepository.getUserById(id).first()
                if (user != null) {
                    call.respond(user)
                } else {
                    call.respond(io.ktor.http.HttpStatusCode.NotFound, "User not found")
                }
            } else {
                call.respond(io.ktor.http.HttpStatusCode.BadRequest, "Invalid ID")
            }
        }
    }
}
