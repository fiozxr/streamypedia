package com.fiozxr.streamypedia.server.routes

import com.fiozxr.streamypedia.data.repository.MediaRepository
import io.ktor.server.application.call
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.route
import io.ktor.server.routing.post
import kotlinx.coroutines.flow.first

fun Route.libraryRoutes(mediaRepository: MediaRepository) {
    route("/api/v1/library") {
        get {
            val search = call.request.queryParameters["search"]
            val genre = call.request.queryParameters["genre"]
            
            // Collect flow to get current list
            val allMedia = mediaRepository.getAllMedia().first()
            
            var filtered = allMedia
            if (!search.isNullOrBlank()) {
                filtered = filtered.filter { it.title.contains(search, ignoreCase = true) }
            }
            if (!genre.isNullOrBlank()) {
                filtered = filtered.filter { it.genres?.contains(genre, ignoreCase = true) == true }
            }
            
            call.respond(filtered)
        }
    }
    
    route("/api/v1/media") {
        get("/{id}") {
            val id = call.parameters["id"]?.toLongOrNull()
            if (id != null) {
                val media = mediaRepository.getMediaById(id).first()
                if (media != null) {
                    call.respond(media)
                } else {
                    call.respond(io.ktor.http.HttpStatusCode.NotFound, "Media not found")
                }
            } else {
                call.respond(io.ktor.http.HttpStatusCode.BadRequest, "Invalid ID")
            }
        }
        
        post("/{id}/fix-match") {
            // Manual match logic to trigger TmdbClient update
            call.respond(io.ktor.http.HttpStatusCode.NotImplemented, "Not implemented yet")
        }
    }
}
