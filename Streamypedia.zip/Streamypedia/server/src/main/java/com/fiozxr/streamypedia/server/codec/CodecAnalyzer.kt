package com.fiozxr.streamypedia.server.codec

import com.arthenica.ffmpegkit.FFprobeKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

data class CodecInfo(
    val videoCodec: String?,
    val audioCodec: String?,
    val container: String?,
    val resolution: String?,
    val duration: Long, // ms
    val bitrate: Long?,
    val hasEmbeddedSubtitles: Boolean,
    val needsConversion: Boolean,
    val needsAudioTranscode: Boolean
)

@Singleton
class CodeAnalyzer @Inject constructor() {

    private val allowedVideoCodecs = setOf("h264", "hevc")
    private val allowedAudioCodecs = setOf("aac", "mp3", "opus", "flac")

    suspend fun analyze(filePath: String): CodecInfo = withContext(Dispatchers.IO) {
        val session = FFprobeKit.execute("-v quiet -print_format json -show_format -show_streams \"$filePath\"")
        val output = session.output
        
        if (session.returnCode.isValueSuccess) {
            parseFfprobeOutput(output)
        } else {
            throw IllegalStateException("FFprobe failed: ${session.failStackTrace}")
        }
    }

    private fun parseFfprobeOutput(jsonOutput: String): CodecInfo {
        val json = JSONObject(jsonOutput)
        val streams = json.optJSONArray("streams") ?: throw IllegalArgumentException("No streams found")
        val format = json.optJSONObject("format")

        var videoCodec: String? = null
        var audioCodec: String? = null
        var width = 0
        var height = 0
        var hasSubtitles = false
        val container = format?.optString("format_name")

        for (i in 0 until streams.length()) {
            val stream = streams.getJSONObject(i)
            val codecType = stream.optString("codec_type")
            val codecName = stream.optString("codec_name")

            if (codecType == "video" && videoCodec == null) {
                videoCodec = codecName
                width = stream.optInt("width", 0)
                height = stream.optInt("height", 0)
            } else if (codecType == "audio" && audioCodec == null) {
                audioCodec = codecName
            } else if (codecType == "subtitle") {
                hasSubtitles = true
            }
        }

        val duration = (format?.optDouble("duration", 0.0) ?: 0.0 * 1000).toLong()
        val bitrate = format?.optLong("bit_rate")
        
        val isVideoAllowed = videoCodec in allowedVideoCodecs
        val isAudioAllowed = audioCodec in allowedAudioCodecs

        val needsConversion = !isVideoAllowed
        val needsAudioTranscode = isVideoAllowed && !isAudioAllowed

        return CodecInfo(
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            container = container,
            resolution = if (width > 0 && height > 0) "${width}x${height}" else null,
            duration = duration,
            bitrate = bitrate,
            hasEmbeddedSubtitles = hasSubtitles,
            needsConversion = needsConversion,
            needsAudioTranscode = needsAudioTranscode
        )
    }
}
