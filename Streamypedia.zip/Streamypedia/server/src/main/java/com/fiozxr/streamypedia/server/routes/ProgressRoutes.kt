package com.fiozxr.streamypedia.server.routes

import com.fiozxr.streamypedia.data.repository.MediaRepository
import com.fiozxr.streamypedia.data.repository.WatchProgressRepository
import com.fiozxr.streamypedia.data.entity.WatchProgressEntity
import io.ktor.server.application.call
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.route
import kotlinx.coroutines.flow.first

data class ProgressRequest(
    val mediaId: Long,
    val position: Long,
    val duration: Long
)

fun Route.progressRoutes(watchProgressRepository: WatchProgressRepository, mediaRepository: MediaRepository) {
    route("/api/v1/users/{userId}/progress") {
        post {
            val userId = call.parameters["userId"]?.toLongOrNull() ?: return@post call.respond(io.ktor.http.HttpStatusCode.BadRequest)
            val request = call.receive<ProgressRequest>()
            
            val entity = WatchProgressEntity(
                userId = userId,
                mediaId = request.mediaId,
                position = request.position,
                duration = request.duration,
                completed = request.position >= request.duration * 0.9,
                lastWatched = System.currentTimeMillis()
            )
            
            watchProgressRepository.upsertProgress(entity)
            call.respond(io.ktor.http.HttpStatusCode.OK)
        }
    }
    
    route("/api/v1/users/{userId}/continue-watching") {
        get {
            val userId = call.parameters["userId"]?.toLongOrNull() ?: return@get call.respond(io.ktor.http.HttpStatusCode.BadRequest)
            val limit = call.request.queryParameters["limit"]?.toIntOrNull() ?: 10
            
            // Should get continue watching from repo, which joins media and progress
            val list = watchProgressRepository.getContinueWatching(userId, limit).first()
            call.respond(list)
        }
    }
}
