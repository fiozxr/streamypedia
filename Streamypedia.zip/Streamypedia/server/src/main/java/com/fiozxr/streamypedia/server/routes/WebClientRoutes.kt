package com.fiozxr.streamypedia.server.routes

import android.content.Context
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.call
import io.ktor.server.response.respond
import io.ktor.server.response.respondBytes
import io.ktor.server.response.respondText
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import java.io.FileNotFoundException

fun Route.webClientRoutes(context: Context) {
    
    val assetManager = context.assets

    fun getMimeType(path: String): ContentType {
        return when {
            path.endsWith(".html") -> ContentType.Text.Html
            path.endsWith(".css") -> ContentType.Text.CSS
            path.endsWith(".js") -> ContentType.Text.JavaScript
            path.endsWith(".png") -> ContentType.Image.PNG
            path.endsWith(".jpg") || path.endsWith(".jpeg") -> ContentType.Image.JPEG
            path.endsWith(".svg") -> ContentType.Image.SVG
            else -> ContentType.Application.OctetStream
        }
    }

    get("/") {
        try {
            val html = assetManager.open("web/index.html").bufferedReader().use { it.readText() }
            call.respondText(html, ContentType.Text.Html)
        } catch (e: Exception) {
            call.respondText("Web client not bundled", status = HttpStatusCode.NotFound)
        }
    }
    
    get("/{path...}") {
        val path = call.parameters.getAll("path")?.joinToString("/") ?: return@get call.respond(HttpStatusCode.BadRequest)
        try {
            val bytes = assetManager.open("web/$path").use { it.readBytes() }
            call.respondBytes(bytes, getMimeType(path))
        } catch (e: FileNotFoundException) {
            // Fallback to index.html for SPA routing if not an API call
            if (!path.startsWith("api/")) {
                try {
                    val html = assetManager.open("web/index.html").bufferedReader().use { it.readText() }
                    call.respondText(html, ContentType.Text.Html)
                } catch (e2: Exception) {
                    call.respond(HttpStatusCode.NotFound)
                }
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        } catch (e: Exception) {
            call.respond(HttpStatusCode.InternalServerError)
        }
    }
}
