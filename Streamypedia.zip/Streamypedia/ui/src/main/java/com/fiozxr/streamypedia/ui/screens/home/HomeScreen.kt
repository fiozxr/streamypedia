package com.fiozxr.streamypedia.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fiozxr.streamypedia.ui.components.AnimatedGradientBackground
import com.fiozxr.streamypedia.ui.components.PosterCard
import com.fiozxr.streamypedia.ui.theme.Typography
import kotlinx.coroutines.flow.StateFlow
import com.fiozxr.streamypedia.data.dto.MediaDto

@Composable
fun HomeScreen(
    continueWatchingFlow: StateFlow<List<MediaDto>>,
    recentlyAddedFlow: StateFlow<List<MediaDto>>,
    onMediaClick: (Long) -> Unit
) {
    val continueWatching by continueWatchingFlow.collectAsState()
    val recentlyAdded by recentlyAddedFlow.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedGradientBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 80.dp, top = 40.dp)
        ) {
            Text(
                text = "Streamypedia",
                style = Typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )

            if (continueWatching.isNotEmpty()) {
                Text(
                    text = "Continue Watching",
                    style = Typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(continueWatching) { media ->
                        PosterCard(
                            media = media,
                            onClick = { onMediaClick(media.id) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            if (recentlyAdded.isNotEmpty()) {
                Text(
                    text = "Recently Added",
                    style = Typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(recentlyAdded) { media ->
                        PosterCard(
                            media = media,
                            onClick = { onMediaClick(media.id) }
                        )
                    }
                }
            }
        }
    }
}
