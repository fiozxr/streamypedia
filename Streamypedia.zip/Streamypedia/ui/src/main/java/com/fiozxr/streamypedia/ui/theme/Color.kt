package com.fiozxr.streamypedia.ui.theme

import androidx.compose.ui.graphics.Color

val DeepIndigo = Color(0xFF1A0533)
val Violet = Color(0xFF2D1B69)
val Teal = Color(0xFF0D3B4F)

val GlassSurface = Color(0x14FFFFFF) // ~8% White
val GlassBorder = Color(0x1EFFFFFF)  // ~12% White
val GlassHighlight = Color(0x33FFFFFF) // ~20% White

val ElectricCyan = Color(0xFF00E5FF)
val SoftViolet = Color(0xFFA855F7)

val PureWhite = Color(0xFFFFFFFF)
val OffWhite = Color(0xEBFFFFFF) // ~92% White
val MutedGray = Color(0x66FFFFFF) // ~40% White

val SuccessGreen = Color(0xCC22C55E)
val WarningAmber = Color(0xCCF59E0B)
val ErrorRed = Color(0xCCEF4444)

val DiffusedShadow = Color(0x4D000000) // ~30% Black
