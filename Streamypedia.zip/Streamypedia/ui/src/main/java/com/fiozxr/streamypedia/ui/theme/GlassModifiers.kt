package com.fiozxr.streamypedia.ui.theme

import android.os.Build
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

fun Modifier.glassPanel(
    cornerRadius: Dp = 20.dp,
    blurRadius: Dp = 30.dp,
    borderOpacity: Float = 0.12f,
    surfaceOpacity: Float = 0.1f,
    hasTopHighlight: Boolean = true
): Modifier = this.then(
    Modifier
        .clip(RoundedCornerShape(cornerRadius))
        .background(Color.White.copy(alpha = surfaceOpacity))
        .then(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Modifier.graphicsLayer {
                    renderEffect = android.graphics.RenderEffect
                        .createBlurEffect(
                            blurRadius.toPx(),
                            blurRadius.toPx(),
                            android.graphics.Shader.TileMode.DECAL
                        )
                        .asComposeRenderEffect()
                }
            } else {
                // Fallback for older APIs - just use a slightly darker semi-transparent background
                Modifier.background(Color.Black.copy(alpha = 0.2f))
            }
        )
        .border(
            width = 1.dp,
            color = Color.White.copy(alpha = borderOpacity),
            shape = RoundedCornerShape(cornerRadius)
        )
        .then(
            if (hasTopHighlight) {
                Modifier.drawWithCache {
                    onDrawWithContent {
                        drawContent()
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(Color.White.copy(alpha = 0.2f), Color.Transparent),
                                start = Offset(0f, 0f),
                                end = Offset(0f, 20.dp.toPx())
                            )
                        )
                    }
                }
            } else {
                Modifier
            }
        )
)

fun Modifier.glassCard(
    cornerRadius: Dp = 20.dp,
    elevation: Dp = 8.dp
): Modifier = this.then(
    Modifier
        .shadow(
            elevation = elevation,
            shape = RoundedCornerShape(cornerRadius),
            spotColor = DiffusedShadow,
            ambientColor = DiffusedShadow
        )
        .glassPanel(cornerRadius = cornerRadius)
)

@Composable
fun Modifier.posterInteraction(
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() }
): Modifier {
    val isPressed by interactionSource.collectIsPressedAsState()
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isInteracting = isPressed || isHovered

    val scale by animateFloatAsState(
        targetValue = if (isInteracting) 1.04f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "posterScale"
    )

    return this.then(Modifier.scale(scale))
}
