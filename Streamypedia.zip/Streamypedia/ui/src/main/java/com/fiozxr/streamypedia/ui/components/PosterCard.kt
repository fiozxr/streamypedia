package com.fiozxr.streamypedia.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.fiozxr.streamypedia.data.dto.MediaDto
import com.fiozxr.streamypedia.ui.theme.Typography
import com.fiozxr.streamypedia.ui.theme.glassPanel
import com.fiozxr.streamypedia.ui.theme.posterInteraction

@Composable
fun PosterCard(
    media: MediaDto,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(120.dp)
            .height(180.dp)
            .posterInteraction()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        AsyncImage(
            model = media.posterPath,
            contentDescription = media.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        
        // Hover/Press overlay could go here for TV/Desktop, but on Mobile we typically
        // just show the image, maybe a small gradient at bottom for text if needed.
        if (media.progress != null && media.progress.position > 0) {
            val progress = media.progress.position.toFloat() / media.progress.duration.toFloat()
            // Progress Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .align(Alignment.BottomCenter)
                    .glassPanel(cornerRadius = 0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .glassPanel(cornerRadius = 0.dp)
                )
            }
        }
    }
}
