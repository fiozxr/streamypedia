package com.fiozxr.streamypedia.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.fiozxr.streamypedia.ui.theme.ElectricCyan
import com.fiozxr.streamypedia.ui.theme.SoftViolet
import com.fiozxr.streamypedia.ui.theme.Typography
import com.fiozxr.streamypedia.ui.theme.glassPanel

enum class GlassButtonVariant {
    PRIMARY, SECONDARY, GHOST
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: GlassButtonVariant = GlassButtonVariant.PRIMARY,
    icon: (@Composable () -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.95f else 1f)

    val bgColor = when (variant) {
        GlassButtonVariant.PRIMARY -> ElectricCyan.copy(alpha = 0.2f)
        GlassButtonVariant.SECONDARY -> SoftViolet.copy(alpha = 0.2f)
        GlassButtonVariant.GHOST -> Color.Transparent
    }

    val contentColor = when (variant) {
        GlassButtonVariant.PRIMARY -> ElectricCyan
        GlassButtonVariant.SECONDARY -> SoftViolet
        GlassButtonVariant.GHOST -> Color.White
    }

    Row(
        modifier = modifier
            .scale(scale)
            .clip(CircleShape)
            .background(bgColor)
            .glassPanel(cornerRadius = 50.dp, hasTopHighlight = variant != GlassButtonVariant.GHOST)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            icon()
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = Typography.labelMedium,
            color = contentColor
        )
    }
}
