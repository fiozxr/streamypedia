package com.fiozxr.streamypedia.ui.screens.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.fiozxr.streamypedia.data.dto.MediaDto
import com.fiozxr.streamypedia.ui.components.AnimatedGradientBackground
import com.fiozxr.streamypedia.ui.components.GlassButton
import com.fiozxr.streamypedia.ui.components.GlassCard
import com.fiozxr.streamypedia.ui.theme.Typography
import kotlinx.coroutines.flow.StateFlow

@Composable
fun DetailScreen(
    mediaFlow: StateFlow<MediaDto?>,
    onPlayClick: (Long) -> Unit,
    onBack: () -> Unit
) {
    val media by mediaFlow.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedGradientBackground()

        if (media != null) {
            val item = media!!
            
            // Backdrop
            AsyncImage(
                model = item.backdropPath,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            )
            
            // Gradient to fade backdrop into background
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xFF1A0533)) // Matches DeepIndigo roughly
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = 220.dp, bottom = 80.dp, start = 20.dp, end = 20.dp)
            ) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = item.title,
                            style = Typography.headlineMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            item.year?.let { Text(it.toString(), style = Typography.bodyMedium) }
                            item.rating?.let { Text("★ $it", style = Typography.bodyMedium) }
                            Text(item.duration.toString(), style = Typography.bodyMedium) // Should be formatted
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        GlassButton(
                            text = "Play",
                            onClick = { onPlayClick(item.id) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Text(
                            text = "Overview",
                            style = Typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = item.overview ?: "No overview available.",
                            style = Typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
