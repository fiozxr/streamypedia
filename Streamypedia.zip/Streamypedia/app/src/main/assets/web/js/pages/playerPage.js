window.Pages = window.Pages || {};

window.Pages.renderPlayerPage = function(container, mediaId) {
  // We need to render the player container first
  container.innerHTML = `
    <div id="player-container" style="width: 100vw; height: 100vh; background: #000; position: fixed; top: 0; left: 0; z-index: 9999;"></div>
  `;

  // Initialize the player
  window.app.activePlayer = new StreamypediaPlayer('player-container');
  
  // Default user if none selected
  const userId = window.app.currentUser ? window.app.currentUser.id : 1;
  
  window.app.activePlayer.init(mediaId, userId, 0); // TODO: get real start position if available
};
