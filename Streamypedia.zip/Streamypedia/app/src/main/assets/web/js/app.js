// Main App Entry
window.app = {
  api: new StreamypediaAPI(),
  currentUser: null,
  activePlayer: null,
  
  init() {
    // Restore user from local storage
    const savedUserId = localStorage.getItem('sp_user_id');
    if (savedUserId) {
      this.currentUser = { id: savedUserId, name: localStorage.getItem('sp_user_name') || 'User' };
    }

    // Router
    window.addEventListener('hashchange', () => this.route());
    this.route();
  },

  async route() {
    const hash = window.location.hash || '#home';
    const container = document.getElementById('app');
    
    // Clean up active player if navigating away
    if (this.activePlayer && !hash.startsWith('#player')) {
      this.activePlayer.destroy();
      this.activePlayer = null;
    }

    // Basic Routing
    if (hash === '#home') {
      window.Pages.renderHome(container);
    } else if (hash === '#library') {
      window.Pages.renderLibrary(container);
    } else if (hash.startsWith('#detail/')) {
      const id = hash.split('/')[1];
      window.Pages.renderDetail(container, id);
    } else if (hash.startsWith('#player/')) {
      const id = hash.split('/')[1];
      window.Pages.renderPlayerPage(container, id);
    } else if (hash === '#search') {
      window.Pages.renderSearch(container);
    } else if (hash === '#profile') {
      window.Pages.renderProfiles(container);
    } else if (hash === '#settings') {
      window.Pages.renderSettings(container);
    } else {
      window.Pages.renderHome(container);
    }

    // Refresh icons
    setTimeout(() => {
      if (window.lucide) window.lucide.createIcons();
    }, 50);
  },

  showToast(message, type = 'info') {
    const toastHtml = window.Components.renderToast(message, type);
    const container = document.getElementById('toast-container');
    container.insertAdjacentHTML('beforeend', toastHtml);
    const toast = container.lastElementChild;
    setTimeout(() => toast.remove(), 3000);
  },
  
  selectUser(id, name) {
    this.currentUser = { id, name };
    localStorage.setItem('sp_user_id', id);
    if(name) localStorage.setItem('sp_user_name', name);
    this.showToast('Profile changed to ' + name, 'success');
    this.route(); // Reload current page
  },
  
  handleSearch(query) {
    if (window.Pages.handleSearchInput) {
      window.Pages.handleSearchInput(query);
    } else {
      window.location.hash = '#search';
      setTimeout(() => {
        if (window.Pages.handleSearchInput) window.Pages.handleSearchInput(query);
      }, 100);
    }
  }
};

// Initialize after DOM load
document.addEventListener('DOMContentLoaded', () => window.app.init());
