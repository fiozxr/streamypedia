window.Pages = window.Pages || {};

window.Pages.renderProfiles = async function(container) {
  container.innerHTML = `
    <div class="page-header glass-panel">
      <h1>Profiles</h1>
    </div>
    <div class="page-content" style="padding-bottom: 80px; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 50vh;">
      ${window.Components.renderShimmer('text')}
    </div>
    ${window.Components.renderNavBar('profile')}
  `;

  try {
    const users = await window.app.api.getUsers();
    const content = container.querySelector('.page-content');
    
    if (!users || users.length === 0) {
      content.innerHTML = window.Components.renderEmptyState('No profiles found.', 'users');
    } else {
      const currentId = window.app.currentUser ? String(window.app.currentUser.id) : null;
      
      const avatarsHtml = users.map(user => {
        const isSelected = currentId === String(user.id);
        const userObj = { id: user.id, name: user.name };
        return `
          <div style="margin: 1rem; cursor: pointer;" onclick="window.app.selectUser('${user.id}', '${user.name.replace(/'/g, "\\'")}')">
            ${window.Components.renderUserAvatar(userObj, isSelected)}
          </div>
        `;
      }).join('');
      
      content.innerHTML = `
        <h2 style="margin-bottom: 2rem;">Who's watching?</h2>
        <div style="display: flex; flex-wrap: wrap; justify-content: center;">
          ${avatarsHtml}
        </div>
      `;
    }
    if (window.lucide) window.lucide.createIcons();
  } catch (e) {
    container.querySelector('.page-content').innerHTML = window.Components.renderEmptyState('Failed to load profiles', 'alert-triangle');
  }
};
