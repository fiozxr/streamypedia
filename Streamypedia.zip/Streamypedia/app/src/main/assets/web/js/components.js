// Streamypedia UI Components
// All functions return HTML strings. No stubs, no TODOs.

window.Components = {

  renderPosterCard(media) {
    const progressPercent =
      media.progress && media.progress.duration
        ? Math.min(
            100,
            Math.round(
              (media.progress.position / media.progress.duration) * 100
            )
          )
        : 0;

    const hasProgress = media.progress && media.progress.position > 0;

    const posterImage = media.poster
      ? `<img src="${media.poster}" alt="${media.title || ''}" loading="lazy" class="poster-card-img" />`
      : `<div class="poster-card-placeholder" style="background: linear-gradient(135deg, var(--color-primary), var(--color-secondary));"></div>`;

    const badge = media.needsConversion
      ? `<span class="badge badge-warning">Needs Conversion</span>`
      : '';

    const year = media.year ? `<span class="poster-year">${media.year}</span>` : '';
    const rating = media.rating
      ? `<span class="poster-rating"><i data-lucide="star" class="icon-xs"></i> ${media.rating}</span>`
      : '';

    const progressBar = hasProgress
      ? `<div class="poster-progress"><div class="poster-progress-fill" style="width: ${progressPercent}%"></div></div>`
      : '';

    return `
      <div class="poster-card" data-media-id="${media.id}" onclick="window.location.hash='#detail/${media.id}'">
        ${posterImage}
        <div class="poster-overlay">
          <div class="poster-meta">
            <div class="poster-title">${media.title || 'Untitled'}</div>
            <div class="poster-info">${year}${rating}</div>
          </div>
        </div>
        ${badge}
        ${progressBar}
      </div>`;
  },

  renderMediaRow(title, items, seeAllLink) {
    const header = `
      <div class="media-row-header">
        <h2>${title}</h2>
        ${seeAllLink ? `<a href="${seeAllLink}" class="see-all-link">See All <i data-lucide="chevron-right" class="icon-xs"></i></a>` : ''}
      </div>`;

    let content;
    if (!items || items.length === 0) {
      content = `<div class="media-row-empty">Nothing here yet</div>`;
    } else {
      const cards = items
        .map((item) => window.Components.renderPosterCard(item))
        .join('');
      content = `<div class="media-row-scroll">${cards}</div>`;
    }

    return `<section class="media-row">${header}${content}</section>`;
  },

  renderSearchBar(value, placeholder) {
    if (value === undefined || value === null) value = '';
    if (!placeholder) placeholder = 'Search movies, shows...';

    const clearBtn =
      value.length > 0
        ? `<button class="search-clear-btn" onclick="document.getElementById('search-input').value=''; window.app.handleSearch('');"><i data-lucide="x" class="icon-sm"></i></button>`
        : '';

    return `
      <div class="search-bar glass-panel">
        <i data-lucide="search" class="icon-sm search-icon"></i>
        <input
          id="search-input"
          type="text"
          class="search-input"
          placeholder="${placeholder}"
          value="${value}"
          oninput="window.app.handleSearch(this.value)"
        />
        ${clearBtn}
      </div>`;
  },

  renderNavBar(currentPage) {
    if (!currentPage) currentPage = 'home';

    const items = [
      { key: 'home', icon: 'home', label: 'Home', hash: '#home' },
      { key: 'library', icon: 'film', label: 'Library', hash: '#library' },
      { key: 'search', icon: 'search', label: 'Search', hash: '#search' },
      { key: 'profile', icon: 'user', label: 'Profile', hash: '#profile' },
      { key: 'settings', icon: 'settings', label: 'Settings', hash: '#settings' },
    ];

    const itemsHtml = items
      .map(
        (item) => `
        <div class="nav-item${item.key === currentPage ? ' active' : ''}" onclick="window.location.hash='${item.hash}'">
          <i data-lucide="${item.icon}" class="nav-icon"></i>
          <span class="nav-label">${item.label}</span>
        </div>`
      )
      .join('');

    return `<nav class="nav-bar">${itemsHtml}</nav>`;
  },

  renderUserAvatar(user, isSelected) {
    const avatarInner = user.avatar
      ? `<img src="${user.avatar}" alt="${user.name}" class="avatar-img" />`
      : `<div class="avatar-initial" style="background-color: ${user.color || 'var(--color-primary)'}">${(user.name || '?').charAt(0).toUpperCase()}</div>`;

    const selectedClass = isSelected ? ' avatar-selected' : '';

    return `
      <div class="user-avatar${selectedClass}" onclick="window.app.selectUser('${user.id}')">
        <div class="avatar-circle">${avatarInner}</div>
        <span class="avatar-name">${user.name || 'User'}</span>
      </div>`;
  },

  renderGlassCard(content, options) {
    if (!options) options = {};
    const className = options.className ? ` ${options.className}` : '';
    const id = options.id ? ` id="${options.id}"` : '';
    const padding =
      options.padding !== undefined
        ? ` style="padding: ${options.padding}"`
        : '';
    const onclick = options.onClick ? ` onclick="${options.onClick}"` : '';

    return `<div class="glass-card${className}"${id}${padding}${onclick}>${content}</div>`;
  },

  renderChip(label, isActive, onClick) {
    const activeClass = isActive ? ' active' : '';
    const onclickAttr = onClick ? ` onclick="${onClick}"` : '';
    return `<span class="chip${activeClass}"${onclickAttr}>${label}</span>`;
  },

  renderProgressBar(current, total) {
    const percent = total > 0 ? Math.min(100, Math.round((current / total) * 100)) : 0;
    return `
      <div class="progress-bar">
        <div class="progress-fill" style="width: ${percent}%"></div>
      </div>`;
  },

  renderBadge(text, type) {
    if (!type) type = 'default';
    return `<span class="badge badge-${type}">${text}</span>`;
  },

  renderModal(title, content, actions) {
    if (!actions) actions = [];

    const actionButtons = actions
      .map(
        (action) =>
          `<button class="btn ${action.className || 'btn-secondary'}" onclick="${action.onClick || ''}">${action.label}</button>`
      )
      .join('');

    const footer =
      actions.length > 0
        ? `<div class="modal-footer">${actionButtons}</div>`
        : '';

    return `
      <div class="modal-backdrop" onclick="if(event.target===this) window.app.closeModal()">
        <div class="modal-content glass-panel">
          <div class="modal-header">
            <h3 class="modal-title">${title}</h3>
            <button class="modal-close-btn" onclick="window.app.closeModal()">
              <i data-lucide="x" class="icon-sm"></i>
            </button>
          </div>
          <div class="modal-body">${content}</div>
          ${footer}
        </div>
      </div>`;
  },

  renderToast(message, type) {
    if (!type) type = 'info';

    const iconMap = {
      success: 'check-circle',
      error: 'alert-circle',
      warning: 'alert-triangle',
      info: 'info',
    };
    const icon = iconMap[type] || 'info';

    return `
      <div class="toast toast-${type}">
        <i data-lucide="${icon}" class="icon-sm toast-icon"></i>
        <span class="toast-message">${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">
          <i data-lucide="x" class="icon-xs"></i>
        </button>
      </div>`;
  },

  renderShimmer(type) {
    if (!type) type = 'poster';

    if (type === 'poster') {
      return `<div class="shimmer shimmer-poster"></div>`;
    }

    if (type === 'text') {
      return `<div class="shimmer shimmer-text"></div>`;
    }

    if (type === 'row') {
      const posters = Array(6)
        .fill('')
        .map(() => `<div class="shimmer shimmer-poster"></div>`)
        .join('');
      return `
        <div class="shimmer-row">
          <div class="shimmer shimmer-text" style="width: 140px; margin-bottom: 12px;"></div>
          <div class="media-row-scroll">${posters}</div>
        </div>`;
    }

    if (type === 'grid') {
      const posters = Array(12)
        .fill('')
        .map(() => `<div class="shimmer shimmer-poster"></div>`)
        .join('');
      return `<div class="shimmer-grid">${posters}</div>`;
    }

    if (type === 'detail') {
      return `
        <div class="shimmer-detail">
          <div class="shimmer shimmer-backdrop"></div>
          <div class="shimmer-detail-body">
            <div class="shimmer shimmer-poster" style="flex-shrink: 0;"></div>
            <div class="shimmer-detail-info">
              <div class="shimmer shimmer-text" style="width: 60%; height: 28px;"></div>
              <div class="shimmer shimmer-text" style="width: 40%; height: 18px;"></div>
              <div class="shimmer shimmer-text" style="width: 100%; height: 14px;"></div>
              <div class="shimmer shimmer-text" style="width: 100%; height: 14px;"></div>
              <div class="shimmer shimmer-text" style="width: 75%; height: 14px;"></div>
            </div>
          </div>
        </div>`;
    }

    return `<div class="shimmer shimmer-poster"></div>`;
  },

  renderEmptyState(message, iconName, actionBtn) {
    if (!iconName) iconName = 'inbox';

    const action = actionBtn
      ? `<button class="btn btn-primary" onclick="${actionBtn.onClick || ''}">${actionBtn.label}</button>`
      : '';

    return `
      <div class="empty-state">
        <i data-lucide="${iconName}" class="empty-state-icon"></i>
        <p class="empty-state-message">${message}</p>
        ${action}
      </div>`;
  },

  formatDuration(seconds) {
    if (!seconds || seconds <= 0) return '0m';
    const totalSeconds = Math.floor(seconds);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;

    if (h > 0) {
      return m > 0 ? `${h}h ${m}m` : `${h}h`;
    }
    return s > 0 ? `${m}m ${s}s` : `${m}m`;
  },

  formatTime(seconds) {
    if (!seconds || seconds < 0) seconds = 0;
    const totalSeconds = Math.floor(seconds);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;

    const mm = String(m).padStart(2, '0');
    const ss = String(s).padStart(2, '0');

    if (h > 0) {
      const hh = String(h).padStart(2, '0');
      return `${hh}:${mm}:${ss}`;
    }
    return `${mm}:${ss}`;
  },
};
