window.Pages = window.Pages || {};

window.Pages.renderSettings = async function(container) {
  container.innerHTML = `
    <div class="page-header glass-panel">
      <h1>Settings</h1>
    </div>
    <div class="page-content" style="padding-bottom: 80px;">
      ${window.Components.renderShimmer('text')}
    </div>
    ${window.Components.renderNavBar('settings')}
  `;

  try {
    const status = await window.app.api.getServerStatus().catch(() => ({ uptime: 'Unknown', connectedUsers: 0 }));
    
    const content = container.querySelector('.page-content');
    
    const settingsHtml = `
      <div class="glass-card" style="padding: 1.5rem; margin-bottom: 1rem;">
        <h2>Server Status</h2>
        <div style="margin-top: 1rem; color: var(--text-secondary);">
          <p><i data-lucide="activity" class="icon-sm"></i> Uptime: ${status.uptime || 'N/A'}</p>
          <p><i data-lucide="users" class="icon-sm"></i> Connected Users: ${status.connectedUsers || 0}</p>
        </div>
      </div>

      <div class="glass-card" style="padding: 1.5rem; margin-bottom: 1rem;">
        <h2>Library</h2>
        <div style="margin-top: 1rem;">
          <button class="btn btn-primary" onclick="window.app.api.triggerScan().then(()=>window.app.showToast('Scan started'))">
            <i data-lucide="refresh-cw"></i> Re-index Library
          </button>
        </div>
      </div>

      <div class="glass-card" style="padding: 1.5rem; margin-bottom: 1rem;">
        <h2>About</h2>
        <div style="margin-top: 1rem; color: var(--text-secondary);">
          <p>Streamypedia v1.0.0</p>
          <p>Your Phone. Your Library. Your Stream.</p>
        </div>
      </div>
    `;
    
    content.innerHTML = settingsHtml;
    if (window.lucide) window.lucide.createIcons();
  } catch (e) {
    container.querySelector('.page-content').innerHTML = window.Components.renderEmptyState('Failed to load settings', 'alert-triangle');
  }
};
