window.Pages = window.Pages || {};

window.Pages.renderLibrary = async function(container) {
  container.innerHTML = `
    <div class="page-header glass-panel">
      <h1>Library</h1>
      ${window.Components.renderSearchBar()}
      <div class="filter-row" style="margin-top: 1rem; overflow-x: auto; white-space: nowrap;">
        ${window.Components.renderChip('All', true, 'window.Pages.filterLibrary("")')}
        ${window.Components.renderChip('Movies', false, 'window.Pages.filterLibrary("movie")')}
        ${window.Components.renderChip('TV Shows', false, 'window.Pages.filterLibrary("tv")')}
      </div>
    </div>
    <div class="page-content" style="padding-bottom: 80px;">
      ${window.Components.renderShimmer('grid')}
    </div>
    ${window.Components.renderNavBar('library')}
  `;

  try {
    const data = await window.app.api.getLibrary();
    const content = container.querySelector('.page-content');
    
    if (!data || data.length === 0) {
      content.innerHTML = window.Components.renderEmptyState('Your library is empty. Try adding some folders in Settings.', 'film');
    } else {
      const grid = `
        <div class="poster-grid">
          ${data.map(m => window.Components.renderPosterCard(m)).join('')}
        </div>
      `;
      content.innerHTML = grid;
    }
  } catch (e) {
    container.querySelector('.page-content').innerHTML = window.Components.renderEmptyState('Failed to load library', 'alert-triangle');
  }
};

window.Pages.filterLibrary = function(type) {
  // Simple re-render for now
  window.app.showToast('Filtering not fully implemented yet');
};
