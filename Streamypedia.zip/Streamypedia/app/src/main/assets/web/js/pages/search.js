window.Pages = window.Pages || {};

window.Pages.renderSearch = function(container) {
  container.innerHTML = `
    <div class="page-header glass-panel">
      <h1>Search</h1>
      ${window.Components.renderSearchBar('', 'Search movies, shows...')}
    </div>
    <div class="page-content" id="search-results" style="padding-bottom: 80px;">
      ${window.Components.renderEmptyState('Type to start searching', 'search')}
    </div>
    ${window.Components.renderNavBar('search')}
  `;
  if (window.lucide) window.lucide.createIcons();
};

let searchTimeout = null;
window.Pages.handleSearchInput = async function(query) {
  const resultsContainer = document.getElementById('search-results');
  if (!resultsContainer) return;

  if (!query || query.trim().length === 0) {
    resultsContainer.innerHTML = window.Components.renderEmptyState('Type to start searching', 'search');
    return;
  }

  if (searchTimeout) clearTimeout(searchTimeout);

  searchTimeout = setTimeout(async () => {
    resultsContainer.innerHTML = window.Components.renderShimmer('grid');
    try {
      const results = await window.app.api.search(query);
      if (!results || results.length === 0) {
        resultsContainer.innerHTML = window.Components.renderEmptyState(`No results found for "${query}"`, 'alert-circle');
      } else {
        const grid = `
          <div class="poster-grid">
            ${results.map(m => window.Components.renderPosterCard(m)).join('')}
          </div>
        `;
        resultsContainer.innerHTML = grid;
      }
    } catch (e) {
      resultsContainer.innerHTML = window.Components.renderEmptyState('Failed to search', 'alert-triangle');
    }
  }, 300); // debounce 300ms
};
