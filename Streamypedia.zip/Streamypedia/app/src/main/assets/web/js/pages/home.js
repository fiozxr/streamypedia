window.HomePage = {
  async render(container) {
    const user = window.app.state.currentUser;
    
    // Show loading shimmers first
    container.innerHTML = `
      <div class="page-container">
        <div class="page-header">
          <div>
            <h1 class="text-2xl font-bold">Welcome back${user ? ', ' + user.name : ''}</h1>
            <p class="text-secondary">What would you like to watch?</p>
          </div>
          ${user ? `<div class="user-avatar-small" onclick="window.location.hash='#profiles'">
            <img src="${user.avatar || ''}" alt="${user.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div class="avatar-initial" style="display:none">${user.name?.charAt(0)?.toUpperCase() || '?'}</div>
          </div>` : ''}
        </div>
        ${Components.renderShimmer('row')}
        ${Components.renderShimmer('row')}
        ${Components.renderShimmer('row')}
      </div>
    `;
    lucide.createIcons();
    
    // Fetch data in parallel
    try {
      const [continueWatching, recentlyAdded, recommendations] = await Promise.allSettled([
        user ? api.getContinueWatching(user.id) : Promise.resolve([]),
        api.getRecentlyAdded(20),
        user ? api.getRecommendations(user.id) : Promise.resolve([])
      ]);
      
      const cw = continueWatching.status === 'fulfilled' ? continueWatching.value : [];
      const ra = recentlyAdded.status === 'fulfilled' ? recentlyAdded.value : [];
      const rec = recommendations.status === 'fulfilled' ? recommendations.value : [];
      
      let contentHtml = `<div class="page-header">
        <div>
          <h1 class="text-2xl font-bold">Welcome back${user ? ', ' + user.name : ''}</h1>
          <p class="text-secondary">What would you like to watch?</p>
        </div>
        ${user ? `<div class="user-avatar-small" onclick="window.location.hash='#profiles'">
          <img src="${user.avatar || ''}" alt="${user.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <div class="avatar-initial" style="display:none">${user.name?.charAt(0)?.toUpperCase() || '?'}</div>
        </div>` : ''}
      </div>`;
      
      if (cw && cw.length > 0) {
        contentHtml += Components.renderMediaRow('Continue Watching', cw);
      }
      if (ra && ra.length > 0) {
        contentHtml += Components.renderMediaRow('Recently Added', ra, '#library');
      }
      if (rec && rec.length > 0) {
        contentHtml += Components.renderMediaRow('Recommended for You', rec);
      }
      if ((!cw || cw.length === 0) && (!ra || ra.length === 0)) {
        contentHtml += Components.renderEmptyState('Your library is empty. Add some media to get started!', 'film');
      }
      
      container.innerHTML = `<div class="page-container">${contentHtml}</div>`;
      lucide.createIcons();
    } catch (err) {
      container.innerHTML = `<div class="page-container">
        ${Components.renderEmptyState('Failed to load content. Please try again.', 'alert-circle')}
      </div>`;
      lucide.createIcons();
    }
  }
};
