// Streamypedia API Client
// All methods fully implemented with fetch(), error handling, and JSON parsing.

class StreamypediaAPI {
  constructor(baseUrl = '') {
    this.baseUrl = baseUrl || window.location.origin;
  }

  async _request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = options.headers || {};

    if (options.method === 'POST' || options.method === 'PUT') {
      headers['Content-Type'] = 'application/json';
    }

    const fetchOptions = {
      ...options,
      headers,
    };

    if (options.body && typeof options.body === 'object') {
      fetchOptions.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, fetchOptions);

    let data = null;
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      const text = await response.text();
      try {
        data = JSON.parse(text);
      } catch {
        data = text;
      }
    }

    if (!response.ok) {
      const errorMessage =
        (data && typeof data === 'object' && (data.error || data.message)) ||
        `Request failed with status ${response.status}`;
      const err = new Error(errorMessage);
      err.status = response.status;
      err.data = data;
      throw err;
    }

    return data;
  }

  // ── Library ────────────────────────────────────────────────────────────

  async getLibrary(params = {}) {
    const query = new URLSearchParams();
    if (params.sort) query.set('sort', params.sort);
    if (params.genre) query.set('genre', params.genre);
    if (params.page) query.set('page', String(params.page));
    if (params.limit) query.set('limit', String(params.limit));
    if (params.search) query.set('search', params.search);

    const qs = query.toString();
    const endpoint = `/api/v1/library${qs ? '?' + qs : ''}`;
    return this._request(endpoint);
  }

  async getMedia(id) {
    return this._request(`/api/v1/media/${encodeURIComponent(id)}`);
  }

  async getStreamUrl(id) {
    return `${this.baseUrl}/api/v1/stream/${encodeURIComponent(id)}/master.m3u8`;
  }

  async getSubtitles(id) {
    return this._request(`/api/v1/media/${encodeURIComponent(id)}/subtitles`);
  }

  // ── User Content ──────────────────────────────────────────────────────

  async getContinueWatching(userId) {
    return this._request(
      `/api/v1/users/${encodeURIComponent(userId)}/continue-watching`
    );
  }

  async getRecentlyAdded(limit = 20) {
    return this._request(`/api/v1/library/recent?limit=${limit}`);
  }

  async getRecommendations(userId) {
    return this._request(
      `/api/v1/users/${encodeURIComponent(userId)}/recommendations`
    );
  }

  async updateProgress(userId, mediaId, position, duration) {
    return this._request(
      `/api/v1/users/${encodeURIComponent(userId)}/progress`,
      {
        method: 'POST',
        body: { mediaId, position, duration },
      }
    );
  }

  // ── Users ─────────────────────────────────────────────────────────────

  async getUsers() {
    return this._request('/api/v1/users');
  }

  async verifyPin(userId, pin) {
    return this._request(
      `/api/v1/users/${encodeURIComponent(userId)}/verify-pin`,
      {
        method: 'POST',
        body: { pin },
      }
    );
  }

  // ── Favorites ─────────────────────────────────────────────────────────

  async getFavorites(userId) {
    return this._request(
      `/api/v1/users/${encodeURIComponent(userId)}/favorites`
    );
  }

  async toggleFavorite(userId, mediaId) {
    return this._request(
      `/api/v1/users/${encodeURIComponent(userId)}/favorites/${encodeURIComponent(mediaId)}`,
      { method: 'POST' }
    );
  }

  // ── Search ────────────────────────────────────────────────────────────

  async search(query) {
    return this._request(
      `/api/v1/search?q=${encodeURIComponent(query)}`
    );
  }

  // ── Server ────────────────────────────────────────────────────────────

  async getServerStatus() {
    return this._request('/api/v1/server/status');
  }

  async getSettings() {
    return this._request('/api/v1/settings');
  }

  async triggerScan() {
    return this._request('/api/v1/library/scan', { method: 'POST' });
  }

  async getScanStatus() {
    return this._request('/api/v1/library/scan/status');
  }

  async setup(config) {
    return this._request('/api/v1/setup', {
      method: 'POST',
      body: config,
    });
  }
}

window.StreamypediaAPI = StreamypediaAPI;
