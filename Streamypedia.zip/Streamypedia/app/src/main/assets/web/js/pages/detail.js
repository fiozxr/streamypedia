window.Pages = window.Pages || {};

window.Pages.renderDetail = async function(container, id) {
  container.innerHTML = `
    <div class="page-content" style="padding-bottom: 80px;">
      ${window.Components.renderShimmer('detail')}
    </div>
    ${window.Components.renderNavBar('')}
  `;

  try {
    const media = await window.app.api.getMedia(id);
    const content = container.querySelector('.page-content');
    
    const backdropStyle = media.backdropPath 
      ? `background-image: url('${media.backdropPath}'); background-size: cover; background-position: center;` 
      : '';

    const needsConvBadge = media.needsConversion 
      ? `<div style="margin-top: 1rem;">${window.Components.renderBadge('Needs Conversion', 'warning')}</div>`
      : '';

    content.innerHTML = `
      <div class="detail-backdrop" style="${backdropStyle}"></div>
      <div class="detail-container">
        <button class="btn btn-ghost detail-back-btn" onclick="window.history.back()"><i data-lucide="arrow-left"></i></button>
        
        <div class="glass-panel detail-content">
          <div class="detail-header">
            ${media.posterPath ? `<img src="${media.posterPath}" class="detail-poster" alt="Poster" />` : '<div class="detail-poster-placeholder"></div>'}
            <div class="detail-info">
              <h1>${media.title || 'Unknown'}</h1>
              <div class="detail-meta">
                ${media.year ? `<span>${media.year}</span>` : ''}
                ${media.rating ? `<span><i data-lucide="star" class="icon-xs"></i> ${media.rating}</span>` : ''}
                ${media.duration ? `<span>${window.Components.formatDuration(media.duration / 1000)}</span>` : ''}
              </div>
              ${needsConvBadge}
              <div class="detail-actions" style="margin-top: 1.5rem;">
                <button class="btn btn-primary btn-giant" onclick="window.location.hash='#player/${media.id}'">
                  <i data-lucide="play"></i> Play
                </button>
                <button class="btn btn-secondary" onclick="window.app.api.toggleFavorite(window.app.currentUser?.id, ${media.id}).then(()=>window.app.showToast('Toggled Favorite'))">
                  <i data-lucide="heart"></i>
                </button>
              </div>
            </div>
          </div>
          
          <div class="detail-synopsis" style="margin-top: 2rem;">
            <h3>Overview</h3>
            <p style="color: var(--text-secondary); line-height: 1.6;">${media.overview || 'No overview available.'}</p>
          </div>
          
          ${media.cast ? `
          <div class="detail-cast" style="margin-top: 2rem;">
            <h3>Cast</h3>
            <p style="color: var(--text-secondary);">${media.cast}</p>
          </div>
          ` : ''}
        </div>
      </div>
    `;
    if (window.lucide) window.lucide.createIcons();
  } catch (e) {
    container.querySelector('.page-content').innerHTML = window.Components.renderEmptyState('Failed to load media details', 'alert-triangle');
  }
};
