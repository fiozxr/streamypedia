class StreamypediaPlayer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.hls = null;
    this.video = null;
    this.controlsTimeout = null;
    this.isPlaying = false;
    this.currentMediaId = null;
    this.currentUserId = null;
    this.subtitleTracks = [];
    this.qualityLevels = [];
    this.progressInterval = null;
    this.duration = 0;
  }

  async init(mediaId, userId, startPosition = 0) {
    this.currentMediaId = mediaId;
    this.currentUserId = userId;
    
    // Clear container
    this.container.innerHTML = `
      <div class="player-wrapper">
        <video id="sp-video" class="sp-video" playsinline></video>
        <div id="sp-loading" class="sp-loading">
          <div class="spinner"></div>
        </div>
        <div id="sp-controls" class="sp-controls glass-panel">
          <div class="sp-controls-top">
            <button class="sp-btn" onclick="window.history.back()">
              <i data-lucide="arrow-left"></i>
            </button>
            <div id="sp-title" class="sp-title">Loading...</div>
          </div>
          
          <div class="sp-controls-center">
            <button class="sp-btn-large" id="btn-skip-back"><i data-lucide="rotate-ccw"></i></button>
            <button class="sp-btn-giant" id="btn-play-pause"><i data-lucide="play"></i></button>
            <button class="sp-btn-large" id="btn-skip-forward"><i data-lucide="rotate-cw"></i></button>
          </div>

          <div class="sp-controls-bottom">
            <div class="sp-time-display">
              <span id="sp-current-time">00:00</span>
              <span class="sp-time-sep">/</span>
              <span id="sp-duration">00:00</span>
            </div>
            
            <div class="sp-timeline-wrapper">
              <input type="range" id="sp-timeline" class="sp-timeline" min="0" max="100" value="0" step="0.1">
              <div class="sp-timeline-progress" id="sp-timeline-progress"></div>
            </div>

            <div class="sp-controls-actions">
              <div class="sp-volume-wrapper">
                <button class="sp-btn" id="btn-mute"><i data-lucide="volume-2"></i></button>
                <input type="range" id="sp-volume" class="sp-volume-slider" min="0" max="1" step="0.05" value="1">
              </div>
              <button class="sp-btn" id="btn-subtitles" style="display:none;"><i data-lucide="message-square"></i></button>
              <button class="sp-btn" id="btn-quality" style="display:none;"><i data-lucide="settings"></i></button>
              <button class="sp-btn" id="btn-pip"><i data-lucide="picture-in-picture"></i></button>
              <button class="sp-btn" id="btn-fullscreen"><i data-lucide="maximize"></i></button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Initialize Lucide icons
    if (window.lucide) {
      window.lucide.createIcons();
    }

    this.video = document.getElementById('sp-video');
    this.setupEventListeners();
    
    try {
      const media = await window.app.api.getMedia(mediaId);
      document.getElementById('sp-title').textContent = media.title || 'Unknown Title';
      
      const streamUrl = await window.app.api.getStreamUrl(mediaId);
      this.setupHls(streamUrl, startPosition);
      
      this.loadSubtitles();
      this.startProgressTracking();
    } catch (e) {
      console.error('Player initialization failed:', e);
      window.app.showToast('Failed to load media stream', 'error');
    }
  }

  setupHls(manifestUrl, startPosition) {
    if (Hls.isSupported()) {
      this.hls = new Hls({
        startPosition: startPosition / 1000,
        enableWorker: true,
        lowLatencyMode: true,
      });
      
      this.hls.loadSource(manifestUrl);
      this.hls.attachMedia(this.video);
      
      this.hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
        document.getElementById('sp-loading').style.display = 'none';
        this.video.play().catch(e => console.log('Autoplay prevented', e));
        
        // Setup quality levels if adaptive
        if (data.levels && data.levels.length > 1) {
          this.qualityLevels = data.levels;
          document.getElementById('btn-quality').style.display = 'block';
        }
      });
      
      this.hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.log("fatal network error encountered, try to recover");
              this.hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.log("fatal media error encountered, try to recover");
              this.hls.recoverMediaError();
              break;
            default:
              this.hls.destroy();
              break;
          }
        }
      });
    } else if (this.video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native HLS (Safari)
      this.video.src = manifestUrl;
      this.video.addEventListener('loadedmetadata', () => {
        document.getElementById('sp-loading').style.display = 'none';
        if (startPosition > 0) this.video.currentTime = startPosition / 1000;
        this.video.play().catch(e => console.log('Autoplay prevented', e));
      });
    }
  }

  setupEventListeners() {
    const playPauseBtn = document.getElementById('btn-play-pause');
    const skipBackBtn = document.getElementById('btn-skip-back');
    const skipForwardBtn = document.getElementById('btn-skip-forward');
    const muteBtn = document.getElementById('btn-mute');
    const fullscreenBtn = document.getElementById('btn-fullscreen');
    const pipBtn = document.getElementById('btn-pip');
    const timeline = document.getElementById('sp-timeline');
    const volume = document.getElementById('sp-volume');
    const controls = document.getElementById('sp-controls');

    // Video events
    this.video.addEventListener('play', () => {
      this.isPlaying = true;
      playPauseBtn.innerHTML = '<i data-lucide="pause"></i>';
      if (window.lucide) window.lucide.createIcons();
    });

    this.video.addEventListener('pause', () => {
      this.isPlaying = false;
      playPauseBtn.innerHTML = '<i data-lucide="play"></i>';
      if (window.lucide) window.lucide.createIcons();
      this.showControls();
    });

    this.video.addEventListener('timeupdate', () => {
      if (!this.video.duration) return;
      this.duration = this.video.duration;
      const current = this.video.currentTime;
      
      document.getElementById('sp-current-time').textContent = window.Components.formatTime(current);
      document.getElementById('sp-duration').textContent = window.Components.formatTime(this.duration);
      
      const percent = (current / this.duration) * 100;
      timeline.value = percent;
      document.getElementById('sp-timeline-progress').style.width = `${percent}%`;
    });

    this.video.addEventListener('waiting', () => {
      document.getElementById('sp-loading').style.display = 'flex';
    });

    this.video.addEventListener('playing', () => {
      document.getElementById('sp-loading').style.display = 'none';
    });

    // Control buttons
    playPauseBtn.addEventListener('click', () => {
      if (this.video.paused) this.video.play();
      else this.video.pause();
    });

    skipBackBtn.addEventListener('click', () => {
      this.video.currentTime = Math.max(0, this.video.currentTime - 10);
    });

    skipForwardBtn.addEventListener('click', () => {
      this.video.currentTime = Math.min(this.video.duration, this.video.currentTime + 10);
    });

    timeline.addEventListener('input', (e) => {
      const time = (e.target.value / 100) * this.video.duration;
      this.video.currentTime = time;
    });

    volume.addEventListener('input', (e) => {
      this.video.volume = e.target.value;
      this.video.muted = e.target.value === '0';
      updateMuteIcon();
    });

    const updateMuteIcon = () => {
      if (this.video.muted || this.video.volume === 0) {
        muteBtn.innerHTML = '<i data-lucide="volume-x"></i>';
      } else {
        muteBtn.innerHTML = '<i data-lucide="volume-2"></i>';
      }
      if (window.lucide) window.lucide.createIcons();
    };

    muteBtn.addEventListener('click', () => {
      this.video.muted = !this.video.muted;
      updateMuteIcon();
    });

    fullscreenBtn.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        this.container.requestFullscreen().catch(err => {
          console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
        });
      } else {
        document.exitFullscreen();
      }
    });

    if (document.pictureInPictureEnabled) {
      pipBtn.addEventListener('click', async () => {
        try {
          if (document.pictureInPictureElement) {
            await document.exitPictureInPicture();
          } else {
            await this.video.requestPictureInPicture();
          }
        } catch (error) {
          console.error(error);
        }
      });
    } else {
      pipBtn.style.display = 'none';
    }

    // Auto-hide controls
    const resetControlsTimeout = () => {
      this.showControls();
      clearTimeout(this.controlsTimeout);
      if (this.isPlaying) {
        this.controlsTimeout = setTimeout(() => {
          this.hideControls();
        }, 3000);
      }
    };

    this.container.addEventListener('mousemove', resetControlsTimeout);
    this.container.addEventListener('touchstart', resetControlsTimeout);
    this.container.addEventListener('click', resetControlsTimeout);

    // Keyboard shortcuts
    document.addEventListener('keydown', this.handleKeydown.bind(this));
  }

  handleKeydown(e) {
    // Only handle if we are the active page
    if (window.location.hash.indexOf('#player') === -1) return;
    
    switch (e.key.toLowerCase()) {
      case ' ':
      case 'k':
        e.preventDefault();
        if (this.video.paused) this.video.play();
        else this.video.pause();
        break;
      case 'arrowleft':
      case 'j':
        e.preventDefault();
        this.video.currentTime = Math.max(0, this.video.currentTime - 10);
        break;
      case 'arrowright':
      case 'l':
        e.preventDefault();
        this.video.currentTime = Math.min(this.video.duration, this.video.currentTime + 10);
        break;
      case 'f':
        e.preventDefault();
        if (!document.fullscreenElement) this.container.requestFullscreen();
        else document.exitFullscreen();
        break;
      case 'm':
        e.preventDefault();
        this.video.muted = !this.video.muted;
        break;
    }
    this.showControls();
  }

  showControls() {
    const controls = document.getElementById('sp-controls');
    if (controls) controls.classList.remove('hidden');
    this.container.style.cursor = 'default';
  }

  hideControls() {
    const controls = document.getElementById('sp-controls');
    if (controls) controls.classList.add('hidden');
    this.container.style.cursor = 'none';
  }

  async loadSubtitles() {
    try {
      const tracks = await window.app.api.getSubtitles(this.currentMediaId);
      if (tracks && tracks.length > 0) {
        this.subtitleTracks = tracks;
        document.getElementById('btn-subtitles').style.display = 'block';
        
        // Add tracks to video element
        tracks.forEach(track => {
          const trackEl = document.createElement('track');
          trackEl.kind = 'subtitles';
          trackEl.label = track.label || track.language;
          trackEl.srclang = track.language;
          trackEl.src = `/api/v1/media/${this.currentMediaId}/subtitles/${track.id}.vtt`;
          this.video.appendChild(trackEl);
        });
      }
    } catch (e) {
      console.log('No subtitles found or error loading:', e);
    }
  }

  startProgressTracking() {
    this.progressInterval = setInterval(() => {
      if (this.isPlaying && this.video.currentTime > 5 && this.duration > 0) {
        window.app.api.updateProgress(
          this.currentUserId,
          this.currentMediaId,
          Math.floor(this.video.currentTime * 1000),
          Math.floor(this.duration * 1000)
        ).catch(e => console.error('Failed to update progress', e));
      }
    }, 10000); // every 10s
  }

  destroy() {
    document.removeEventListener('keydown', this.handleKeydown);
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
    }
    if (this.hls) {
      this.hls.destroy();
    }
    if (this.video) {
      this.video.pause();
      this.video.src = '';
      this.video.load();
    }
    this.container.innerHTML = '';
  }
}

window.StreamypediaPlayer = StreamypediaPlayer;
