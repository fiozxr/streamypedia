package com.fiozxr.streamypedia.di

import android.content.Context
import com.fiozxr.streamypedia.server.ServerConfig
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideContext(@ApplicationContext context: Context): Context {
        return context
    }

    @Provides
    @Singleton
    fun provideServerConfig(): ServerConfig {
        return ServerConfig(
            port = 8096,
            serverName = "Streamypedia",
            remoteAccessEnabled = true
        )
    }
}
