package com.fiozxr.streamypedia.service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.fiozxr.streamypedia.server.KtorServer
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class StreamingService : Service() {

    @Inject
    lateinit var ktorServer: KtorServer

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification(0)
        startForeground(1, notification)
        
        // Start embedded Ktor server
        ktorServer.start()
        
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        ktorServer.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotification(userCount: Int): Notification {
        return NotificationCompat.Builder(this, "server_channel")
            .setContentTitle("Streamypedia Server")
            .setContentText("Running — $userCount users connected")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }
}
