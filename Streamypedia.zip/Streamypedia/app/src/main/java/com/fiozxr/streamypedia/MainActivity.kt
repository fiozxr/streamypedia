package com.fiozxr.streamypedia

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.fiozxr.streamypedia.service.StreamingService
import com.fiozxr.streamypedia.ui.screens.home.HomeScreen
import com.fiozxr.streamypedia.ui.screens.player.PlayerScreen
import com.fiozxr.streamypedia.ui.theme.StreamypediaTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Start foreground service for Ktor server
        startService(Intent(this, StreamingService::class.java))

        setContent {
            StreamypediaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                continueWatchingFlow = MutableStateFlow(emptyList()), // Mocked for now
                                recentlyAddedFlow = MutableStateFlow(emptyList()),
                                onMediaClick = { id -> navController.navigate("player/$id") }
                            )
                        }
                        composable(
                            route = "player/{mediaId}",
                            arguments = listOf(navArgument("mediaId") { type = NavType.LongType })
                        ) { backStackEntry ->
                            val mediaId = backStackEntry.arguments?.getLong("mediaId") ?: 0L
                            PlayerScreen(mediaId = mediaId)
                        }
                    }
                }
            }
        }
    }
}
